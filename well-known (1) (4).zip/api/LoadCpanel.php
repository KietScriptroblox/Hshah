<?php
include('../cpn/config.php');
include('apiCpanel.php');

$type = $_POST['type'];

if($type == 'loaddomain'){
$username = $_POST['username'];
$password = $_POST['password'];
$ip = $_POST['ip'];

if (empty($username) || empty($password) || empty($ip)){
     echo '<option>Không Nhận Được Dữ Liệu</option>';
} else {
    
    $cPanel = new cPanel($username, $password, $ip);
    
    $response = $cPanel->execute('uapi', 'DomainInfo', 'list_domains');
    
    if (isset($response->data->main_domain)) {
        echo '<option value="'.$response->data->main_domain.'">'.$response->data->main_domain.'</option>';
    }
    
    if (!empty($response->data->parked_domains)) {
        foreach ($response->data->parked_domains as $parkedDomain) {
            echo '<option value="'.$parkedDomain.'">'.$parkedDomain.'</option>';
        }
    }
    
    if (!empty($response->data->sub_domains)) {
        foreach ($response->data->sub_domains as $subDomain) {
            echo '<option value="'.$subDomain.'">'.$subDomain.'</option>';
        }
    }
    
    if (!empty($response->data->addon_domains)) {
        foreach ($response->data->addon_domains as $addonDomain) {
            echo '<option value="'.$addonDomain.'">'.$addonDomain.'</option>';
        }
    }

}

}

?>