<?php
include('ini.php');

    $domain = $_POST['domain'];
    $dot = $_POST['dot'];
    $explode = explode(".", $domain);
    $hsd = $_POST['hsd'];
    $nameserver = $_POST['nameserver'];
    $timehethan = time() + (31536000 + $hsd);
    
    if (count($explode) > 1) {
        $dot = $explode[1];
    } else {
        $dot = $explode[1];
    }

    $query = $connect->query("SELECT * FROM `DomainPackages` WHERE `name` = '".$dot."'")->fetch_array();
    $limitDomain = $connect->query("SELECT * FROM `Domain` WHERE `domain` = '$resDomain' WHERE `status` IN(0, 1)")->num_rows;    
    $tienphaitra = $query['price'] * $hsd;    
        
    $discounts = $_POST['discount'];
    $queryDiscounts = $connect->query("SELECT * FROM MaGiamGia WHERE code = '$discounts' AND service = 'domain'")->fetch_array();
    $limitDiscounts = $connect->query("SELECT * FROM MaGiamGia WHERE code = '$discounts' AND luotdung <= '".$queryDiscounts['gioihan']."' AND service = 'domain'")->num_rows;
    
    if($discounts != '' && $discounts == $queryDiscounts['code'] && $queryDiscounts['luotdung'] <= $queryDiscounts['gioihan']){
        if($queryDiscounts['loai'] == 'phantram'){
            $tienphaitra = checkGia($tienphaitra, $queryDiscounts['giamgia']);
        } else if($queryDiscounts['loai'] == 'tien'){
            $tienphaitra = $tienphaitra - $queryDiscounts['giamgia'];
        }
       $statusDiscount = 'true';
    }

    
    if(empty($domain)){
        echo swal("Miền Không Hợp Lệ","error");
        echo redirect('/');
    } else if(!isDomainRegistered($resDomain)) {
        echo swal("Tên Miền Đã Được Đăng Ký!","error");
        echo redirect('/');
    } else if(empty($hsd) || $hsd < 1 || $hsd > 12 ){
        echo swal("Hạn Sử Dụng Không Hợp Lệ!".$dot,"error");
    } else if(empty($nameserver)) {
        echo swal("Vui Lòng Nhập DNS Hoặc IP!","error");
    } else if($limitDomain > 1){
        echo swal("Tên Miền Đã Được Đăng Ký!","error");
    } else if(!isset($_SESSION['users'])){
        echo swal("Vui Lòng Đăng Nhập!","error");
        echo redirect('/');
    } else if(!empty($discounts) && $limitDiscounts < 1){
        echo json_api('Mã Giảm Giá Không Hợp Lệ', 'error');
    } else if($getUser['monney'] < $tienphaitra) {
        echo swal("Số Dư Không Đủ Để Thanh Toán!","error");
    } else {
        $inTrue = $connect->query("INSERT INTO `Domain`(`id`, `username`, `domain`, `ns`, `hsd`, `status`, `time`, `overtime`, `timedelete`) VALUES (NULL,'".$getUser['username']."','$domain','$nameserver','$hsd','0','".time()."','$timehethan','0')");
        if($inTrue){
            
        if($statusDiscount == 'true'){
            $connect->query("UPDATE MaGiamGia SET luotdung = luotdung + '1' WHERE code = '$discounts'");
        }
            
            $connect->query("UPDATE `Users` SET `monney` = `monney` - '$tienphaitra' WHERE `username` = '".$getUser['username']."'");
            echo swal("Thanh Toán Thành Công!","success");
        } else {
            echo swal("Thanh Toán Thất Bại","error");
        }
    }
?>