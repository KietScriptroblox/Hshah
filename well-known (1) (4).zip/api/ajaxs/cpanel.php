<?php
include('ini.php');

$type = $_POST['type'];

if($type == 'changepassword'){
    $pass = $_POST['pass'];
    $id = $_POST['id'];
    $whmusername = $_POST['whmusername'];
    $whmpassword = $_POST['whmpassword'];
    $hostname = $_POST['hostname'];
    $query = $connect->query("SELECT * FROM `DanhSachHosting` WHERE `id` = '$id' AND `username` = '".$getUser['username']."'")->fetch_array();
    
    if(empty($id) || $id != $query['id']){
        echo '<p class="text-danger"> Đơn Hàng Không Tồn Tại </p>';
    } else if(empty($pass)){
        echo '<p class="text-danger"> Vui Lòng Nhập Mật Khẩu Mới! </p>';
    } else if($pass == $query['matkhau']){
        echo '<p class="text-danger"> Mật Khẩu Không Có Thay Đổi? </p>';
    } else {
        
            $query = $hostname.':2087/json-api/passwd?api.version=1&user='.$query['taikhoan'].'&password='.$pass.'&enabledigest=0&db_pass_update=1'; 
            $curl = curl_init(); 
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0); 
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
            curl_setopt($curl, CURLOPT_HEADER,0); 
            curl_setopt($curl, CURLOPT_RETURNTRANSFER,1); 
            $header[0] = "Authorization: Basic " . base64_encode($whmusername.":".$whmpassword) . "\n\r";
            curl_setopt($curl, CURLOPT_HTTPHEADER, $header);  
            curl_setopt($curl, CURLOPT_URL, $query);
            $result = curl_exec($curl); 
            $result = curl_exec($curl);
            if ($result == false) {
                echo swal('Không Thể Kết Nối Đến Cpanel','error');
            } else {
                 $inTrue = $connect->query("UPDATE `DanhSachHosting` SET `matkhau`='$pass' WHERE id = '$id'");
                    if($inTrue){
                        echo '<p class="text-success"> Thao Tác Thành Công! </p>';
                    } else {
                        echo '<p class="text-danger"> Thao Tác Thất Bại </p>';
                    }
            }
            curl_close($curl);
            
       
    }
} else if($type == 'giahan'){
    
$hsd = $_POST['hsd'];
$id = $_POST['id'];
$query = $connect->query("SELECT * FROM DanhSachHosting WHERE id = '$id'")->fetch_array();
$package = $connect->query("SELECT * FROM PackageHosting WHERE package = '".$query['package']."'")->fetch_array();
$getName = $connect->query("SELECT * FROM ServerName WHERE uname = '".$package['server']."'")->fetch_array();
$tienphaitra = $package['price'] * $hsd;
$timedangco = $query['orvertime'];
$timesapco = 2592000 * $hsd;
$unsuspendacct = time()+(2592000*$hsd);
$tongtime = $timedangco + $timesapco;

$timesuspended = time()+(86400*3);

if($package['price'] < 1000){
    $hsd = '0';
}

if(empty($id)){
    echo 'Dịch Vụ Không Hợp Lệ!';
} else if(empty($hsd) || $hsd < 1 || $hsd > 12){
    echo '<b class="text-danger">Hạn Dùng Không Hợp Lệ!</b>';
} else if(!isset($_SESSION['users'])){
    echo '<b class="text-danger">Vui Lòng Đăng Nhập!</b>';
} else if($getUser['monney'] < $tienphaitra){
    echo '<b class="text-danger">Không Đủ Tiền Để Gia Hạn!</b>';
} else {
    
    if($query['status'] == '4'){
        $query = $getName['hostname'].':2087/json-api/unsuspendacct?api.version=1&user='.$query['taikhoan'].'&password='.$query['matkhau'].'&enabledigest=0&db_pass_update=1'; 
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0); 
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
        curl_setopt($curl, CURLOPT_HEADER,0); 
        curl_setopt($curl, CURLOPT_RETURNTRANSFER,1); 
        $header[0] = "Authorization: Basic " . base64_encode($getName['whmusername'].":".$getName['whmpassword']) . "\n\r";
        curl_setopt($curl, CURLOPT_HTTPHEADER, $header); 
        curl_setopt($curl, CURLOPT_URL, $query); 
        $result = curl_exec($curl); 
        
        if ($result == false) {
            echo swal('Không Thể Kết Nối Đến Cpanel','error');
        } else {
            $inUpdate = $connect->query("UPDATE DanhSachHosting SET orvertime = '$unsuspendacct', status = '1', timesuspended = '' WHERE id = '$id'");
            if($inUpdate){
                echo '<b class="text-success"> Gia Hạn Thành Công! </b>';
                $connect->query("UPDATE Users SET `monney` = `monney` - $tienphaitra, `re_monney` = `re_monney` + $tienphaitra WHERE username = '".$getUser['username']."'");
            } else {
                echo '<b class="text-danger">Gia Hạn Thất Bại</b>';
            }
        }
        curl_close($curl);
    
    
    } else {
    
    $inUpdate = $connect->query("UPDATE DanhSachHosting SET orvertime = '$tongtime' WHERE id = '$id'");
    if($inUpdate){
        echo '<b class="text-success">Gia Hạn Thành Công!</b>';
        $connect->query("UPDATE Users SET `monney` = `monney` - $tienphaitra, `re_monney` = `re_monney` + $tienphaitra WHERE username = '".$getUser['username']."'");
        echo redirect('');
    } else {
        echo '<b class="text-danger">Không Thể Thực Hiện Yêu Cầu!</b>';
    }
    
    }
}

} else if($type == 'upgrade'){
$package = $_POST['packagee'];
$id = $_POST['id'];
$query = $connect->query("SELECT * FROM DanhSachHosting WHERE id = '$id'")->fetch_array();
$old_package = $connect->query("SELECT * FROM PackageHosting WHERE package = '".$query['package']."'")->fetch_array();
$new_package = $connect->query("SELECT * FROM PackageHosting WHERE id = '$package'")->fetch_array();
$getName = $connect->query("SELECT * FROM ServerName WHERE uname = '".$new_package['server']."'")->fetch_array();

$tienConLai  = TruTienDichVu($query['time'], $old_package['price'], $hsd);
$tienphaitra = $new_package['price'] - $tienConLai;

if($query['status'] == '1'){
if(empty($id) || $id != $query['id']){
    echo '<b class="text-danger">Dịch Vụ Không Hợp Lệ!</b>';
} else if(empty($package) || $package != $new_package['id']){
    echo '<b class="text-danger">Gói Không Hợp Lệ</b>';
} else if(!isset($_SESSION['users'])){
    echo '<b class="text-danger">Vui Lòng Đăng Nhập!</b>';
} else if($getUser['monney'] < $tienphaitra){
    echo '<b class="text-danger">Không Đủ Tiền Để Nâng Cấp!</b>';
} else if($new_package['price'] < $old_package['price']){
    echo '<b class="text-danger">Bạn Phải Đăng Ký Gói Cao Hơn Gói Hiện Tại!</b>';
} else {
    
    $query = $getName['hostname'].':2087/json-api/changepackage?api.version=1&user='.$query['taikhoan'].'&pkg='.$getName['whmusername'].'_'.$new_package['package']; 
    $curl = curl_init(); 
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0); 
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0); 
    curl_setopt($curl, CURLOPT_HEADER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1); 
    $header[0] = "Authorization: Basic " . base64_encode($getName['whmusername'].":".$getName['whmpassword']) . "\n\r";
    curl_setopt($curl, CURLOPT_HTTPHEADER, $header); 
    curl_setopt($curl, CURLOPT_URL, $query);
    $result = curl_exec($curl); 
    
    if ($result == false) {
        echo '<b class="text-danger">Không Thể Nâng Cấp</b>';
    } else {
        $inUpdate = mysqli_query($connect, "UPDATE `DanhSachHosting` SET `package`='".$new_package['package']."' WHERE id = '$id'");
        if($inUpdate){
            $connect->query("UPDATE Users SET `monney` = `monney` - $tienphaitra, `re_monney` = `re_monney` + $tienphaitra WHERE username = '".$getUser['username']."'");
            echo '<b class="text-success">Nâng Cấp Thành Công Lên Gói '.inHoaString(AntiXss($new_package['package'])).' </b>';
        } else {
            echo '<b class="text-danger">Không Thể Thực Hiện Yêu Cầu!'.  $response['metadata']['reason'].'</b>';
        }
    }


    curl_close($curl);
} 

} else {
    echo '<b class="text-danger"> Hành động không hợp lệ! </b>';
}

} else if($type == 'addsubdomain'){

    include('../apiCpanel.php');
    
  
    $domain = $_POST['domain'];
    $rootdomain = $_POST['rootdomain'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $ip = $_POST['ip'];
    
    $cPanel = new cPanel($username, $password, $ip);
    
    $params = array(
        "domain" => $domain,
        "rootdomain" => $rootdomain,
        "dir" => "/".$domain.'.'.$rootdomain
    );
    
    $response = $cPanel->execute('uapi', 'SubDomain', 'addsubdomain', $params);
    
    if($response->status == 1){
        echo 'Thêm Tên Miền <strong class="text-primary">'.$domain.'.'.$rootdomain.'</strong>  Thành Công ';
    } else {
        echo '<strong class="text-danger"> '.print_r($response).' </strong>'; 
    } 
        
    }
    
?>