<?php
include('ini.php');

    $id = $_POST['id'];
    $package = $connect->query("SELECT * FROM PackageHosting WHERE id = '$id'")->fetch_array();
    $getName = $connect->query("SELECT * FROM ServerName WHERE uname = '".$package['server']."'")->fetch_array();
    $checkLimit = $connect->query("SELECT * FROM DanhSachHosting WHERE domain = '".$_POST['domain']."' AND status IN (0, 1, 4) AND server = '".$getName['uname']."'")->num_rows;
    
    $hostname = $getName['hostname'];
    $whmusername = $getName['whmusername'];
    $whmpassword = $getName['whmpassword'];
    $ip = $getName['ip'];
    
    $taikhoan = inThuongString('ChiDung'.RandStrings(7));
    $matkhau = RandStrings(15);
    
    $tienphaitra = $package['price'] * $_POST['hsd'];
    $orvertime = time()+(2592000 * $_POST['hsd']);

    $discounts = $_POST['discount'];
    $queryDiscounts = $connect->query("SELECT * FROM MaGiamGia WHERE code = '$discounts' AND service = 'host'")->fetch_array();
    $limitDiscounts = $connect->query("SELECT * FROM MaGiamGia WHERE code = '$discounts' AND luotdung <= '".$queryDiscounts['gioihan']."' AND service = 'host'")->num_rows;
    
    if($discounts != '' && $discounts == $queryDiscounts['code'] && $queryDiscounts['luotdung'] <= $queryDiscounts['gioihan']){
        if($queryDiscounts['loai'] == 'phantram'){
            $tienphaitra = checkGia($tienphaitra, $queryDiscounts['giamgia']);
        } else if($queryDiscounts['loai'] == 'tien'){
            $tienphaitra = $tienphaitra - $queryDiscounts['giamgia'];
        }
       $statusDiscount = 'true';
    }


    if(empty($id)){
        echo json_api('Gói Hosting Bạn Chọn Không Hợp Lệ','error');
    } else if(empty($_POST['domain'])){
        echo json_api('Vui Lòng Nhập Tên Miền','error');
    } else if(!empty($discounts) && $limitDiscounts < 1){
        echo json_api('Mã Giảm Giá Không Hợp Lệ', 'error');
    } else if($getUser['monney'] < $tienphaitra){
        echo json_api('Số Dư Không Đủ Để Thanh Toán','error');
    } else if($checkLimit == 1){
        echo json_api('Tên Miền Đã Tồn Tại Trên Máy Chủ Này','error');
    } else {
        
        $connect->query("UPDATE Users SET `monney` = `monney` + $tienphaitra, `re_monney` = `re_monney` + $tienphaitra WHERE username = '".$getUser['username']."'");
        
        $query = $hostname.':2087/json-api/createacct?api.version=1&username='.$taikhoan.'&domain='.$_POST['domain'].'&plan='.$whmusername.'_'.$package['package'].'&featurelist=jupiter&password='.$matkhau.'&ip=n&cgi=1&hasshell=1&contactemail='.$_POST['email'].'&cpmod=paper_lantern&language=en'; 
        $curl = curl_init(); 
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0); 
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0); 
        curl_setopt($curl, CURLOPT_HEADER,0);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER,1); 
        $header[0] = "Authorization: Basic " . base64_encode($whmusername.":".$whmpassword) . "\n\r";
        curl_setopt($curl, CURLOPT_HTTPHEADER, $header); 
        curl_setopt($curl, CURLOPT_URL, $query);
        $result = curl_exec($curl); 
        $data = json_decode($result, true);
        
        if ($result === false) {
            if($result == '') echo json_api('Hệ Thống Máy Chủ Này Đang Bận, Hãy Thử Lại Sau', 'error'); else echo json_api('Có lỗi xảy ra, hãy kiểm tra lại', 'error');
            $connect->query("UPDATE Users SET `monney` = `monney` + $tienphaitra, `re_monney` = `re_monney` - $tienphaitra WHERE username = '".$getUser['username']."'");
        } else {
            
            if(isset($data['metadata']['result'])){
                 if($data['metadata']['result'] == 1){
                    $inTrue = $connect->query("INSERT INTO `DanhSachHosting`(`id`, `username`, `domain`, `email`, `package`, `server`, `status`, `time`, `orvertime`, `timesuspended`, `taikhoan`, `matkhau`, `lidokhoa`) VALUES (NULL,'".$getUser['username']."','".$_POST['domain']."','".$_POST['email']."','".$package['package']."','".$getName['uname']."','1','".time()."','$orvertime','0','$taikhoan','$matkhau','0')");
                    if($inTrue){
                        
                    if($statusDiscount == 'true'){
                        $connect->query("UPDATE MaGiamGia SET luotdung = luotdung + '1' WHERE code = '$discounts'");
                    }
        
                        echo json_api('Mua Hosting Thành Công!', 'success');
                    } else {
                        echo json_api('Không Thể Lưu Dữ Liệu', 'error');
                    }
                   
            } else {
                echo json_api('Không thể tạo hosting, hãy thử đổi tên miền khác và thử lại!', 'error');
                $connect->query("UPDATE Users SET `monney` = `monney` + $tienphaitra, `re_monney` = `re_monney` - $tienphaitra WHERE username = '".$getUser['username']."'");
            }
            } else {
                echo json_api('Lỗi máy chủ', 'error');
                $connect->query("UPDATE Users SET `monney` = `monney` + $tienphaitra, `re_monney` = `re_monney` - $tienphaitra WHERE username = '".$getUser['username']."'");
            }
            
            } 
            
            curl_close($curl); 
            
    }
        
        
?>