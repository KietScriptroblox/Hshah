<?php
include('ini.php');

$type = $_POST['type'];

if($type == 'changepassword'){
    $password = $_POST['password'];
    $id = $_POST['id'];
    $query = $connect->query("SELECT * FROM `DanhSachReseller` WHERE `id` = '$id' AND `username` = '".$getUser['username']."'")->fetch_array();
    $apiQuery = json_decode(file_get_contents("https://cyberlux.vn/Api/api.php?type=info_reseller&apikey=$apikey&domain=".$query['domain']), true);
    
    if(empty($id) || $id != $query['id']){
        echo json_encode(['message' => 'Dịch vụ không hợp lệ2!', 'status' => 'error']);
    } else if(empty($password)){
        echo json_encode(['message' => 'Vui lòng nhập mật khẩu mới!', 'status' => 'error']);
    } else if($getUser['username'] != $query['username']) {
        echo json_encode(['message' => 'Bạn không có quyền quản lý dịch vụ này!', 'status' => 'error']);
    } else if($apiQuery['status_r'] == 1) {
        
        
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, "https://cyberlux.vn/Api/api.php?type=changepass_reseller&domain=".$query['domain']."&password=$password&apikey=$apikey");
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        $response_data = curl_exec($curl);
        
        if (curl_errno($curl)) {
            echo json_encode(['message' => 'cURL Error: ' . curl_error($curl), 'status' => 'error']);
        } else {
            $response = json_decode($response_data, true);
            echo json_encode(['message' => $response['message'], 'status' => $response['status']]);
        }
        
        curl_close($curl);

        
    } else {
        echo json_encode(['message' => 'Chức năng chỉ hỗ trợ khi dịch vụ hoạt động!', 'status' => 'error']);
    }
    

} else if($type == 'giahan'){
    
    $id = $_POST['id'];
    $hsd = $_POST['hsd'];
    
    $query = $connect->query("SELECT * FROM `DanhSachReseller` WHERE `id` = '$id' AND `username` = '".$getUser['username']."'")->fetch_array();
    $apiQuery = json_decode(file_get_contents("https://cyberlux.vn/Api/api.php?type=info_reseller&apikey=$apikey&domain=".$query['domain']), true);
    $package = json_decode(file_get_contents("https://cyberlux.vn/Api/api.php?type=getpackage_reseller2&package=".$query['package']), true);
    $getName = json_decode(file_get_contents("https://cyberlux.vn/Api/api.php?type=query_server_reseller&uname=".$query['server']), true);

    
    $tienphaitra = $package['price'] * $hsd;
    $timedangco = $apiQuery['orvertime'];
    $timesapco = 2592000 * $hsd;
    $unsuspendacct = time()+(2592000*$hsd);
    $tongtime = $timedangco + $timesapco;
    
    $hostname = $getName['hostname'];
    $whmusername = $getName['whmusername'];
    $whmpassword = $getName['whmpassword'];
    $timesuspended = time()+(86400*3);
    
    if(empty($id) || $id != $query['id']){
        echo json_api('Dịch Vụ Không Hợp Lệ!', 'error');
    } else if(empty($hsd) || $hsd < 1 || $hsd > 12){
        echo json_api('Hạn Dùng Không Hợp Lệ!', 'error');
    } else if($getUser['monney'] < $tienphaitra){
        echo json_api('Không Đủ Tiền Để Gia Hạn!','error');
    } else {
        
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, "https://cyberlux.vn/Api/api.php?type=giahan_reseller&domain=".$query['domain']."&hsd=$hsd&apikey=$apikey");
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        $response_data = curl_exec($curl);
        
        if (curl_errno($curl)) {
            echo json_encode(['message' => 'cURL Error: ' . curl_error($curl), 'status' => 'error']);
        } else {
            $response = json_decode($response_data, true);
            
            if($response['status'] == 'success'){
                $connect->query("UPDATE Users SET `monney` = `monney` - $tienphaitra, `re_monney` = `re_monney` + $tienphaitra WHERE username = '".$getUser['username']."'");
            }
            
            echo json_encode(['message' => $response['message'], 'status' => $response['status']]);
        }
        
        curl_close($curl);
        
    }

}

?>