<?php
include('../cpn/config.php');

echo Title("Đăng Xuất Tài Khoản");

unset($_SESSION['users']);
echo redirect('/');
?>