<?php
include('../cpn/header.php');
$query = $connect->query("SELECT * FROM `DanhSachWeb` WHERE `id` = '".$_GET['id']."' AND `username` = '".$getUser['username']."'")->fetch_array();
$theme = $connect->query("SELECT * FROM `Products` WHERE `id` = '".$query['theme']."'")->fetch_array();
 
if($_GET['id'] != $query['id'] || empty($_GET['id'])){
    echo redirect('/');
} else if($getUser['username'] != $query['username']){
    echo swal("Bạn không có quyền quản lý dịch vụ này!","error");
    echo redirect('/');
}

echo Title("Chi tiết dịch vụ - #".inHoaString($query['domain']));
?>


<div class="main-content app-content">
                    <div class="side-app">
                        <div class="main-container container-fluid px-0">
                             
                            <div class="page-header">
                                <div class="page-leftheader">
                                    <h4 class="page-title mb-0 text-primary"> Chi Tiết Dịch Vụ - #<?=($query['id']);?> </h4>
                                </div>
                            </div>
  
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="row m-0">

                                                <div class="col-lg-12 p-md-0">
                                                 
                                                        <div class="tab-content">
                                                            <div class="tab-pane active text-center" id="tab01">
                                                                <div class="row my-7">
                                                                    <div class="my-8 col-md-9 d-block mx-auto">
                                                                        <img src="https://cdn-icons-png.flaticon.com/512/9481/9481555.png" alt="img" class="w-10 mb-4">
                                                                        <h4 class="font-weight-bold mt-2"><a href="https://<?=$query['domain'];?>" target="_blank" class="text-primary"> <?=inHoaString($query['domain']);?> </a> </h4>
                                                                        <p class="text-muted"> Nếu dịch vụ hết hạn sau 3 ngày bạn không gia hạn dịch vụ sẽ bị xóa vĩnh viễn, <strong class="text-danger">không thể khôi phục</strong>! </p>
                                                                        
                                                                        <div class="mt-5 text-center">
                                                                            <h3 class=" text-danger"> Thông tin dịch vụ </h3>
                                                                            
                                                                            <ul>
                                                                                <p> Tên Miền: <a href="https://<?=$query['domain'];?>" class="text-primary"> <?=inHoaString($query['domain']);?> </a></p>
                                                                                <p> Thông Tin Quản Trị: <?=$query['taikhoan'];?> | <?=$query['matkhau'];?> </p>
                                                                                <p> Giao Diện: <a href="/tao-web/<?=$theme['id'];?>"> <?=$theme['name'];?> </a></p>
                                                                                <p> Ngày Mua: <?=ToTime($query['time']);?> </p>
                                                                                <p> Ngày Hết Hạn: <?=ToTime($query['orvertime']);?> </p>
                                                                                <p> Ghi Chú Từ Admin: "<?=$query['ghichu'];?>" </p>
                                                                                
                                                                                <button class="btn btn-success" data-bs-toggle="modal" href="#giahan"> Gia Hạn </button>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                
                <div class="modal fade effect-flip-horizontal" id="giahan" aria-modal="true" role="dialog">
                            <div class="modal-dialog modal-dialog-centered text-center" role="document">
                                <div class="modal-content modal-content-demo">
                                    <div class="modal-header">
                                        <h6 class="modal-title"> Gia Hạn Dịch Vụ </h6><button aria-label="Close" class="btn-close" data-bs-dismiss="modal" type="button"><span aria-hidden="true">×</span></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <select class="form-control" id="hsd" onchange="getPrice()">
                                                <option value="1"> 1 Tháng </option>
                                                <option value="3"> 3 Tháng </option>
                                                <option value="6"> 6 Tháng </option>
                                                <option value="9"> 9 Tháng </option>
                                                <option value="12"> 12 Tháng </option>
                                            </select>
                                        </div>
                                        
                                    </div>
                                    
                                    <div class="text-center" id="message" width="100px">
                                        
                                    </div>
                                    
                                    <div class="modal-footer">
                                        <button class="btn btn-primary" id="btn-submit" type="button" onclick="submit()"> Thanh Toán - <span id="price">0</span><sup>đ</sup></button>
                                        <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        
                        <script>
                        
                        window.onload = getPrice;
                        
                        function submit(){
                            $('#btn-submit').html('<img src="https://mir-s3-cdn-cf.behance.net/project_modules/disp/04de2e31234507.564a1d23645bf.gif" width="30px">').prop('disabled', true);
                             $.ajax({
                                    url: "/api/ajaxs/giahan-web.php",
                                    method: "POST",
                                    data: {
                                        id: '<?=$query['id'];?>',
                                        hsd: $("#hsd").val(),
                                    },
                                    success: function(response) {
                                        var data = JSON.parse(response);
                                        
                                        console.log(data);
                                        
                                        if(data.status == 'error'){
                                            document.getElementById('message').innerHTML = `<strong class="text-danger">${data.message}</strong><br>`;
                                        } else if(data.status == 'success'){
                                            document.getElementById('message').innerHTML = `<strong class="text-success">${data.message}</strong><br>`;
                                        }
                                        $('#btn-submit').html('Thanh Toán - <span id="price">0</span><sup>đ</sup>').prop('disabled', false);
                                        getPrice();
                                    }
                                });
                        }
    
    
                            function getPrice(){
                                const price = '<?=$theme['price'];?>';
                                const hsd = document.getElementById("hsd").value;
                                
                                const tongtien = price * hsd;
                                let vndString = tongtien.toLocaleString('vi-VN', { style: 'currency', currency: 'VND' }); 
                                let codeflow = vndString.replace('₫', ''); 
                                document.getElementById('price').innerHTML = codeflow;
                            }
                        </script>
                            
                
                
                
<?php
include('../cpn/footer.php');
?>