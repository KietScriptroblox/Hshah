<?php
include('../cpn/header.php');
$id = $_GET['id'];
$data = file_get_contents("$hostapi/Api/api.php?type=getpackage_reseller&id=$id");
$query = json_decode($data, true);
$data2 = file_get_contents("$hostapi/Api/api.php?type=query_server_reseller&uname=".$query['server']);
$getName = json_decode($data2, true);

if($id != $query['id']){
    echo redirect('/');
}

checkSession();

echo Title("Thanh Toán Dịch Vụ #".$query['id']);
?>


<div class="main-content app-content">
                    <div class="side-app">
                        <!-- CONTAINER -->
                        <div class="main-container container-fluid px-0">
                                
                            <!-- PAGE-HEADER -->
                            <div class="page-header">
                                <div class="page-leftheader">
                                    <h4 class="page-title mb-0 text-primary"> THANH TOÁN DỊCH VỤ #<?=$query['id'];?></h4>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="card">
                                        <div class="card-header">
                                            <h3 class="card-title"> ĐẶT HÀNG </h3>
                                        </div>
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="form-group col-md-6">
                                                    <label>Tên Miền</label>
                                                    <input type="text" class="form-control" placeholder="Nhập tên miền" id="domain">
                                                </div>
                                                
                                                <div class="form-group col-md-6">
                                                    <label> Hạn Dùng </label>
                                                    <select class="form-control" id="hsd" onchange="getPrice()">
                                                        <option value="1"> 1 Tháng </option>
                                                        <option value="3"> 3 Tháng </option>
                                                        <option value="6"> 6 Tháng </option>
                                                        <option value="9"> 9 Tháng </option>
                                                        <option value="12"> 12 Tháng </option>
                                                    </select>
                                                </div>
                                                
                                                
                                                <div class="form-group col-md-12">
                                                    <label> Email </label>
                                                    <input type="text" class="form-control" placeholder="Tài Khoản" id="email" value="<?=$getUser['email'];?>">
                                                </div>

                                            </div>
                                            
                                            <div class="col-md-12">
                                                <button class="btn btn-info" id="btn-submit" onclick="submit()"> Thanh Toán - <span id="price">0</span><sup>đ</sup></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                
                                <div class="col-md-6">
                                    <div class="ibox card">
                                        <div class="card-body">
                                            <div class="ibox-content">
                                                <div class="row mb-3">
                                                    <div class="col-md-12 col-lg-12">
                                                            <h3> Thông Tin Dịch Vụ </h3>
                                                            <div class="mt-5">
                                                                <p> Gói Dịch Vụ: <?=inHoaString($query['package']); ?></p>
                                                                <p> Máy Chủ: <?=$getName['name'];?> </p>
                                                                <p> Giá Dịch Vụ: <?=Monney($query['price']);?><sup>đ</sup></p>
                                                                
                                                                <?php if($getName['mota'] != null){
                                                                    echo 'Mô Tả Máy Chủ: <strong class="text-danger">'.$getName['mota'].'</strong>';
                                                                } ?> 
                                                                
                                                                <br>
                                                                
                                                                <button class="mt-5 btn btn-danger" onclick="window.location.href='/package-reseller/<?=$getName['uname'];?>';"> Chọn Gói Khác </button>
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                
                            </div>
                            
                            
                        
                        </div>
                    </div>
                </div>
                 </div>
                 
                 
                         
        <script>
            window.onload = getPrice;
            
            function getPrice(){
                const price = '<?=$query['price'];?>';
                const hsd = document.getElementById("hsd").value;
                
                const tongtien = price * hsd;
                let vndString = tongtien.toLocaleString('vi-VN', { style: 'currency', currency: 'VND' }); 
                let codeflow = vndString.replace('₫', ''); 
                document.getElementById('price').innerHTML = codeflow;
            }
                                    
            function submit(){
                $('#btn-submit').html('<img src="https://mir-s3-cdn-cf.behance.net/project_modules/disp/04de2e31234507.564a1d23645bf.gif" width="30px">').prop('disabled', true);
                 $.ajax({
                        url: "/api/ajaxs/thanhtoan-reseller.php",
                        method: "POST",
                        data: {
                            id: '<?=$query['id'];?>',
                            domain: $("#domain").val(),
                            email: $("#email").val(),
                            hsd: $("#hsd").val(),
                            discount: $("#discount").val(),
                        },
                        success: function(response) {
                            var data = JSON.parse(response);
                            
                            swal('Thông Báo', data.message, data.status);
                            
                            $('#btn-submit').html('Thanh Toán - <span id="price">0</span><sup>đ</sup>').prop('disabled', false);
                            getPrice();
                        }
                    });
            }
        </script>
                
                
<?php
include('../cpn/footer.php');
?>