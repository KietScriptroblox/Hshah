<?php
include('../cpn/header.php');
echo Title("Danh Sách Máy Chủ Reseller Giá Rẻ");
?>



<div class="main-content app-content">
                    <div class="side-app">
                        <div class="main-container container-fluid px-0">
                                
                            <div class="page-header">
                                <div class="page-leftheader">
                                    <h4 class="page-title mb-0 text-primary"> DANH SÁCH MÁY CHỦ </h4>
                                </div>
                            </div>
                            
               
                            
                            <div class="col-sm-12 col-lg-12 col-xl-12 p-0">
                                <div class="row">
                            <?php
                                $getServer = file_get_contents("$hostapi/Api/api.php?type=get_server_reseller");
                                $response = json_decode($getServer, true); 
                                
                                $id = 0;
                                
                                foreach ($response as $row) {
                                    $id += 1;

                            ?>
                            
                                    <div class="col-xxl-3 col-sm-6 col-lg-6 col-xl-4 alert">
                                        <div class="card item-card ">
                                            <div class="card-body pb-0">
                                                <div class="text-center zoom">
                                                    <img src="https://tenten.vn/tin-tuc/wp-content/uploads/2019/07/625942-for-more-on-web-hosting-4.jpg" alt="img" class="img-fluid w-100 br-7">
                                                </div>
                                                <div class="card-body ps-0 pb-3">
                                                    <center><a class=""> Máy Chủ <?=$row['name'];?> </a></center> 
                                                </div>
                                            </div>
                                            
                                            <div class="text-center pb-4 ps-2 pe-2">
                                                <a href="/package-reseller/<?=$row['uname'];?>" class="btn btn-danger"><i class="fe fe-shopping-cart me-1"></i> Xem Ngay </a>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <?php } ?>
                                    
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>



<?php
include('../cpn/footer.php');
?>