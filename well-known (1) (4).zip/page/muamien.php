<?php
include('../cpn/header.php');

if(isset($_POST['domain'])){
    $_SESSION['domain'] = $_POST['domain'];
}

$domain = $_SESSION['domain'];

$explode = explode(".", $domain);
$query = $connect->query("SELECT * FROM DomainPackages WHERE name = '".$explode[1]."'")->fetch_array();
if(empty($domain) || $explode[1] != $query['name']){
    echo redirect('/');
}

if(empty($domain)){
    echo swal("Tên Miền Không Hợp Lệ!", "error");
    echo redirect('/');
} else if(isDomainRegistered($domain)){

echo Title("Kiểm Tra Tên Miền - Bảng Giá Miền");
?>

           <div class="main-content app-content">
                    <div class="side-app">
                        <!-- CONTAINER -->
                        <div class="main-container container-fluid px-0">
                                
                            <!-- PAGE-HEADER -->
                            <div class="page-header">
                                <div class="page-leftheader">
                                    <h4 class="page-title mb-0 text-primary"> Mua Tên Miền </h4>
                                </div>
                            </div>
                            
                           
                           
                           <div class="row">
                                <div class="col-md-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <h3 class="card-title"> ĐẶT HÀNG </h3>
                                        </div>
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="form-group col-md-6">
                                                    <label>Tên Miền</label>
                                                    <input type="text" class="form-control" placeholder="Nhập tên miền" value="<?=$domain;?>" id="domain" disabled>
                                                </div>
                                                
                                                <div class="form-group col-md-6">
                                                    <label> Hạn Dùng </label>
                                                    <select class="form-control" id="hsd" onchange="checkGia()">
                                                        <option value="1"> 1 Năm </option>
                                                        <option value="3"> 3 Năm </option>
                                                        <option value="6"> 6 Năm </option>
                                                        <option value="9"> 9 Năm </option>
                                                        <option value="12"> 12 Năm </option>
                                                    </select>
                                                </div>
                                                
                                                
                                                <div class="form-group col-md-12">
                                                    <label> Nameserver Hoặc IP </label>
                                                    <textarea class="form-control" rows="3" id="nameserver" placeholder="Mỗi NS Cách Nhau Bằng Dấu Phẩy"></textarea>
                                                </div>

                                            </div>
                                            
                                            <div class="col-md-12">
                                                <button class="btn btn-info" onclick="thanhToan()" id="ThanhToan"> Thanh Toán - <span id="price">0</span><sup>đ</sup></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                </div>
                                
                       
                        </div>
                        
                    </div>
                </div>


                <script>
                    function checkGia(){
                        const price = <?=$query['price'];?>;
                        const hsd = document.getElementById("hsd").value;
                        
                        let tongtien = price * hsd;
                        let vndString = tongtien.toLocaleString('vi-VN', { style: 'currency', currency: 'VND' }); 
                        let cyberlux = vndString.replace('₫', ''); 
                        document.getElementById("price").innerHTML = cyberlux;
                    }
                    
                    
                    function thanhToan(){
                        swal({
                          title: "Xác nhận?",
                          text: "Bạn có chắc muốn mua dịch vụ này?",
                          icon: "warning",
                          buttons: true,
                          dangerMode: true,
                        })
                        .then((willDelete) => {
                          if (willDelete) {
                            pay();
                          }
                        });
                    }
                    
                    function pay(){
                        $('#ThanhToan').html('<i class="fa fa-spinner fa-spin"></i>').prop('disabled', true);
                         $.ajax({
                                url: "/api/ajaxs/muamien.php",
                                method: "POST",
                                data: {
                                    domain: $("#domain").val(),
                                    hsd: $("#hsd").val(),
                                    nameserver: $("#nameserver").val(),
                                    discount: $("#discount").val(),
                                },
                                success: function(response) {
                                    $('#nhthanhit').html(response);
                                    $('#ThanhToan').html('Thanh Toán - <strong id="money">0</strong> <sup>đ</sup>').prop('disabled', false);
                                    checkGia();
                                }
                            });
                    }
                    
                    checkGia();
                </script>

  <div id="nhthanhit" type="hidden"></div>
<?php
}
else {
    echo redirect('/');
}
include('../cpn/footer.php');
?>