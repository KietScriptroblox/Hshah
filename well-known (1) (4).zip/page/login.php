<?php
include('../cpn/config.php');
include('../cpn/components/head.php');
?>
<script>
    document.title = 'Đăng Nhập Tài Khoản';
</script>

	<body class="login-page">

		<div id="global-loader" >
			<img src="/build/assets/images/svgs/loader.svg" alt="loader">
		</div>


        <div class="register-2">
                    
            <div class="page">
                <div class="page-content">
                    <div class="container">
                        <div class="row">
                            <div class="col mx-auto mt-5">
                                <div class="row justify-content-center">
                                    <div class="col-md-7 col-lg-5 col-xl-4">
                                        <div class="text-center mb-5">
                                            <a href="/"><img src="<?=$system32['logo'];?>" class="header-brand-img"
                                                alt="Logo"></a>
                                        </div>
                                        <div class="card">
                                            <div class="card-body">
                                                <div class="text-center mb-3">
                                                    <h1 class="mb-2"> Đăng Nhập </h1>
                                                    <a href="javascript:void(0);"> Chào Mừng Trở Lại! </a>
                                                </div>
                                                <div class="mt-5">
                                                    <div class="input-group mb-4">
                                                        <div class="input-group-text">
                                                            <i class="fe fe-user"></i>
                                                        </div>
                                                        <input type="text" class="form-control" id="username" placeholder="Tên đăng nhập">
                                                    </div>
                                                    
                                                    <div class="input-group mb-4">
                                                        <div class="input-group">
                                                            <a href="javascript:void(0);" class="input-group-text">
                                                                <i class="fe fe-eye" aria-hidden="true"></i>
                                                            </a>
                                                            <input class="form-control" type="password" id="password"
                                                                placeholder="Mật khẩu">
                                                        </div>
                                                    </div>
                                                    

                                                    <div class="form-group text-center mb-3">
                                                        <button id="btn-submit" class="btn btn-primary w-100 br-7" onclick="submit()"> Đăng Nhập </button>
                                                    </div>
                                                    
                                                    <div class="form-group fs-13 text-center">
                                                        <a href="/forgot-password"> Quên mật khẩu? </a>
                                                    </div>
                                                    
                                                    <div class="form-group fs-14 text-center">
                                                        Chưa có tài khoản?, <a href="/register" class="text-primary"> Đăng ký </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="text-center register-icons">
                                            <div class="small text-white mb-4">Login with</div>
                                            <button class="btn bg-white-50  text-white-50 font-weight-semibold w-12 google me-2"
                                                type="button"><i class="fa fa-google"></i></button>
                                            <button
                                                class="btn bg-white-50  text-white-50 font-weight-semibold  w-12 facebook me-2"
                                                type="button"><i class="fa fa-facebook-f"></i></button>
                                            <button
                                                class="btn bg-white-50  text-white-50 font-weight-semibold w-12 twitter me-2"
                                                type="button"><i class="fa fa-twitter"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


<script>
    function submit(){
                 $('#btn-submit').html('<img src="https://mir-s3-cdn-cf.behance.net/project_modules/disp/04de2e31234507.564a1d23645bf.gif" width="30px">').prop('disabled', true);
         $.ajax({
            url: "/api/ajaxs/auth.php",
            method: "POST",
            data: {
                type: 'login',
                username: $("#username").val(),
                password: $("#password").val()
            },
            success: function(response) {
                var data = JSON.parse(response);
                
                swal('Thông Báo', data.message, data.status);
                
                if(data.status == 'success'){
                    window.location.href="/";
                }
                
                $('#btn-submit').html('<i class="fa fa-fw fa-sign-in-alt opacity-50 me-1"></i> Đăng Nhập').prop('disabled', false);
            }
        });
    }
</script>
            
        <script src="/build/assets/plugins/jquery/jquery.min.js"></script>
        <script src="/build/assets/plugins/bootstrap/popper.min.js"></script>
        <script src="/build/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
        <script src="/build/assets/plugins/p-scrollbar/p-scrollbar.js"></script>
        <script src="/build/assets/plugins/bootstrap/bootstrap-show-password.min.js"></script>
        <link rel="modulepreload" href="/build/assets/themeColors.2c059b7b.js" /><link rel="modulepreload" href="/build/assets/apexcharts.common.4772fa83.js" /><script type="module" src="/build/assets/themeColors.2c059b7b.js"></script>
		<link rel="modulepreload" href="/build/assets/app.f4590aff.js" /><link rel="modulepreload" href="/build/assets/apexcharts.common.4772fa83.js" /><script type="module" src="/build/assets/app.f4590aff.js"></script>
	</body>
</html>
