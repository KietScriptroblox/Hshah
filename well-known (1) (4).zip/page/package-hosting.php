<?php
include('../cpn/header.php');
$query = $connect->query("SELECT * FROM `ServerName` WHERE `id` = '".$_GET['id']."'")->fetch_array();

if($query['id'] != $_GET['id']){
    echo redirect('/');
}

echo Title("Danh Sách Gói Hosting Máy Chủ ".$query['name']);
?>



<div class="main-content app-content">
                    <div class="side-app">
                        <div class="main-container container-fluid px-0">
                                
                            <div class="page-header">
                                <div class="page-leftheader">
                                    <h4 class="page-title mb-0 text-primary"> DANH SÁCH GÓI HOSTING <?=inHoaString($query['name']);?> </h4>
                                </div>
                            </div>
                            
                           
                           
                           <div class="row">
                               
                               <?php
                                        $response=$connect->query("SELECT * FROM `PackageHosting` WHERE `server`='".$query['uname']."'");
                                        foreach($response as $row){
                                            $id+=1;
                                        ?>
                                        
                                        
                                    <div class="col-xs-6 col-sm-6 col-xl-3 mt-2">
                                        <div class="card shadow-none">
                                            <div class="card-header text-white align-items-center">
                                                <div class="card-title mx-auto text-center">
                                                    <h3 class=" text-primary font-weight-semibold mt-3 mb-2"> CPANEL <?=inHoaString($row['package']);?> </h3>
                                                    <div class="mb fs-13 text-info"> <?=Monney($row['price']);?><sup>đ</sup>/ Tháng </div>
                                                </div>
                                            </div>
                                            
                                            <div class="card-body text-center  pricing">
                                                <ul class="list-unstyled leading-loose">
                                                    <li class="text-dark border-bottom"> Dung Lượng: <strong> <?=$row['disk'];?> </strong></li>
                                                    
                                                    <li class="text-dark border-bottom"> Băng Thông: <strong> <?=$row['bandwidth'];?> </strong></li>
                                                    
                                                    <li class="text-dark border-bottom"> Miền Khác: <strong> <?=$row['addondomain'];?> </strong></li>
                                                    
                                                    <li class="text-dark border-bottom"> Miền Con: <strong> <?=$row['subdomain'];?> </strong></li>
                                                    
                                                    <li class="text-dark border-bottom"> Backup: <strong> <?=$query['backup'];?> </strong></li>
                                                    
                                                    <li class="text-dark border-bottom"> SSL: <strong> <?=$query['ssl_key'];?> </strong></li>
                                                    
                                                </ul>
                                                <div class="text-center mt-5">
                                                    <a href="/thanhtoan-hosting/<?=$row['id'];?>" class="btn btn-primary"> Mua Ngay </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <?php } ?>
                                    
                                    </div>
                                            
                                            

                        </div>
                    </div>
                </div>



<?php
include('../cpn/footer.php');
?>