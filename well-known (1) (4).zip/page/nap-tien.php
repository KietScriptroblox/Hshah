<?php
include('../cpn/header.php');
checkSession();
echo Title("Nạp Tiền Qua Ngân Hàng - Ví");
?>


<div class="main-content app-content">
                    <div class="side-app">
                        <!-- CONTAINER -->
                        <div class="main-container container-fluid px-0">
                                
                            <!-- PAGE-HEADER -->
                            <div class="page-header">
                                <div class="page-leftheader">
                                    <h4 class="page-title mb-0 text-primary"> Thông Tin Chuyển Khoản </h4>
                                </div>
                            </div>
                            
                           <div class="content content-boxed">
                                <div class="row">
                                    
                                    <?php
                                    $query = $connect->query("SELECT * FROM `Banks`");
                                    foreach($query as $row){
                                    ?>
                                        <div class="col-md-4">
                                                <div class="card">
                                                <div class="block block-rounded block-bordered block-link-shadow h-100 mb-0">
                                                    <div class="block-content mt-3">
                                                        <center><img src="<?=$row['image'];?>" width="90px"></center><br>
                                                        <table class="table table-borderless table-striped">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="fw-medium text-muted">
                                                                        <i class="fa fa-fw fa-credit-card me-1 text-danger"></i> Số Tài Khoản: <strong> <?=$row['sotaikhoan'];?> </strong>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="fw-medium text-muted">
                                                                        <i class="fa fa-fw fa-id-card me-1"></i> Chủ Tài Khoản: <strong> <?=$row['chutaikhoan'];?> </strong>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="fw-medium text-muted">
                                                                        <i class="fa fa-btc me-1"></i> Nạp Tối Thiểu: <strong> <?=$row['toithieu'];?> </strong>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="fw-medium text-muted">
                                                                        <i class="fa fa-fw fa-copy me-1"></i> Nội Dung: <strong class="text-primary"> naptien_<?=$getUser['username'];?> </strong>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                    <?php } ?>
                                
                            </div>


                                
                            </div>
                             
                            </div>
                            
                            
                        
                        </div>
                    </div>
                </div>
                 </div>
                 
                
<?php
include('../cpn/footer.php');
?>