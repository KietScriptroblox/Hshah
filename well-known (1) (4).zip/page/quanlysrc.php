<?php
include('../cpn/header.php');

echo checkSession();

echo Title("Quản Lý Web");
?>

<div class="main-content app-content">
                    <div class="side-app">
<div class="main-container container-fluid px-0">
                                
                            <div class="page-header">
                                <div class="page-leftheader">
                                    <h4 class="page-title mb-0 text-primary"> Quản Lý Mã Nguồn </h4>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-md-6 mb-4">
                                                    <a href="/mua-source" class="btn btn-primary"><i class="fe fe-plus"></i> Thêm Dịch Vụ </a>
                                                </div>
                                                <div class="col-md-6 col-auto">
                                                </div>
                                            </div>
                                            
                                            <div class="e-table">
                                                <div class="table-responsive">
                                                    <table class="table table-vcenter text-nowrap border mb-0 table-hover" id="invoicedatatable">
                                                        <thead>
                                                            <tr>
                                                                <th></th>
                                                                <th> ID </th>
                                                                <th> Tên Code </th>
                                                                <th> Giá Mua </th>
                                                                <th> Thời Gian Mua  </th>
                                                                <th> Thao Tác </th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            
                                                            <?php
                                                            $response = $connect->query("SELECT * FROM `DanhSachCode` WHERE `username` = '".$getUser['username']."' ORDER BY id DESC");
                                                            foreach($response as $row){
                                                                $theme = $connect->query("SELECT * FROM `SourceCode` WHERE `id` = '".$row['theme']."'")->fetch_array();
                                                                $id+=1;
                                                            ?>
                                                            
                                                            <tr>
                                                                <td class="align-middle w-5">
                                                                    <label class="custom-control custom-checkbox">
                                                                        <input type="checkbox" class="custom-control-input" name="example-checkbox2" value="option2">
                                                                        <span class="custom-control-label"></span>
                                                                    </label>
                                                                </td>
                                                                
                                                                <td class="align-middle">
                                                                    <div class="d-flex">
                                                                        <div class="mt-1">
                                                                            #<?=$row['id'];?>
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                                
                                                                <td class="text-nowrap align-middle">
                                                                   <?=$row['name'];?>
                                                                </td>
                                                             
                                                                <td class="text-nowrap align-middle">
                                                                    <?=Monney($row['price']);?><sup>đ</sup>
                                                                </td>
                                                                
                                                                <td class="text-nowrap align-middle"> <?=ToTime($row['time']);?> </td>
                                                                
                                                                <td>
                                                                    <div class="dropdown">
                                                                        <button class="btn btn-light btn-sm" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                                            Options <i class="fa fa-angle-down"></i>
                                                                        </button>
                                                                        <ul class="dropdown-menu">
                                                                            <li>
                                                                                <a class="dropdown-item" onclick="window.open('<?=$theme['code'];?>', 'CYBERLUX.VN')"><i class="fe fe-eye me-2"></i> Tải Về </a>
                                                                            </li>
                                                                          
                                                                        </ul>
                                                                    </div>
                                                                </td>
                                                                
                                                            </tr>
                                                            
                                                            <?php } if($id < 1){ ?>
                                                            
                                                                <td colspan="8" class="text-center"> Không có dữ liệu:( </td>
                                                            
                                                            <?php } ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- END ROW -->

                        </div>
                         </div>
                         </div>
                        
                        
<?php
include('../cpn/footer.php');
?>