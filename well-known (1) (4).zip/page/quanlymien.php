<?php
include('../cpn/header.php');

echo checkSession();

echo Title("Quản Lý Tên Miền");
?>

<div class="main-content app-content">
                    <div class="side-app">
<div class="main-container container-fluid px-0">
                                
                            <div class="page-header">
                                <div class="page-leftheader">
                                    <h4 class="page-title mb-0 text-primary"> Tên Miền Đã Mua </h4>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-md-6 mb-4">
                                                    <a href="/bang-gia-mien" class="btn btn-primary"><i class="fe fe-plus"></i> Thêm Dịch Vụ </a>
                                                </div>
                                                <div class="col-md-6 col-auto">
                                                </div>
                                            </div>
                                            
                                            <div class="e-table">
                                                <div class="table-responsive">
                                                    <table class="table table-vcenter text-nowrap border mb-0 table-hover" id="invoicedatatable">
                                                        <thead>
                                                            <tr>
                                                                <th></th>
                                                                <th> ID </th>
                                                                <th> Tên Miền </th>
                                                                <th> Chu Kì </th>
                                                                <th> DNS </th>
                                                                <th> Thời Gian Mua  </th>
                                                                <th> Thời Gian Hết Hạn </th>
                                                                <th> Trạng Thái </th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            
                                                            <?php
                                                            $response = $connect->query("SELECT * FROM `Domain` WHERE `username` = '".$getUser['username']."' ORDER BY id DESC");
                                                            foreach($response as $row){
                                                                $id+=1;
                                                            ?>
                                                            
                                                            <tr>
                                                                <td class="align-middle w-5">
                                                                    <label class="custom-control custom-checkbox">
                                                                        <input type="checkbox" class="custom-control-input" name="example-checkbox2" value="option2">
                                                                        <span class="custom-control-label"></span>
                                                                    </label>
                                                                </td>
                                                                
                                                                <td class="align-middle">
                                                                    <div class="d-flex">
                                                                        <div class="mt-1">
                                                                            #<?=$row['id'];?>
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                                
                                                                <td class="text-nowrap align-middle">
                                                                   <a href="https://<?=$row['domain'];?>" target="_blank" class="text-primary"> <?=inHoaString($row['domain']);?> </a>
                                                                </td>
                                                             
                                                                <td class="text-nowrap align-middle">
                                                                    <?=$row['hsd'];?> Năm
                                                                </td>
                                                                
                                                                <td class="text-nowrap align-middle"> <?=($row['ns']);?> </td>
                                                                
                                                                <td class="text-nowrap align-middle"> <?=ToTime($row['time']);?> </td>
                                                                
                                                                <td class="text-nowrap align-middle"> <?=ToTime($row['overtime']);?> </td>
                                                                
                                                                <td class="text-nowrap align-middle"> <?=StatusDomain($row['status']);?> </td>
                                                            </tr>
                                                            
                                                            <?php } if($id < 1){ ?>
                                                            
                                                                <td colspan="8" class="text-center"> Không có dữ liệu:( </td>
                                                            
                                                            <?php } ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- END ROW -->

                        </div>
                         </div>
                         </div>
                        
                        
<?php
include('../cpn/footer.php');
?>