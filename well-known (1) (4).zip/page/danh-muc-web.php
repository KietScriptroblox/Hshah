<?php
include('../cpn/header.php');
$query = $connect->query("SELECT * FROM `DanhMuc` WHERE id = '".$_GET['id']."'")->fetch_array();

if($query['id'] != $_GET['id']){
 echo redirect('/');
}

echo Title("DANH MỤC ".$query['name']);
?>

           <div class="main-content app-content">
                    <div class="side-app">
                        <!-- CONTAINER -->
                        <div class="main-container container-fluid px-0">
                                
                            <!-- PAGE-HEADER -->
                            <div class="page-header">
                                <div class="page-leftheader">
                                    <h4 class="page-title mb-0 text-primary"> DANH MỤC <?=$query['name'];?> </h4>
                                </div>
                            </div>
                            
                            
                            
                            <div class="row">
                                <div class="col-lg-12 col-xl-12">
                                    <div class="row">
                                        
                                        <?php
                                        $respone = $connect->query("SELECT * FROM `Products` WHERE `danhmuc` = '".$query['id']."'");
                                        foreach($respone as $row){
                                        ?>
                                        
                                        <div class="col-xl-4 col-md-6 alert mb-0">
                                            <div class="card item-card ">
                                                <div class="card-body pb-0">
                                                    <div class="text-center zoom">
                                                        <a href="/danh-muc-web/<?=$row['id'];?>"><img src="<?=$row['image'];?>" class="img-fluid" style="width: 100%; max-height: 250px;"></a>
                                                    </div>
                                                    
                                                    <div class="card-body px-0 pb-3">
                                                        <div class="row">
                                                            <div class="col-12" style="text-align: center;">
                                                                <strong class="text-start"><?=$row['name'];?></strong>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="text-center pb-4 ps-2 pe-2">
                                                    <a href="<?=$row['demo'];?>" target="_blank" class="btn btn-md bg-primary-transparent text-primary mb-2 border-primary w-45 text-wrap"><i class="fe fe-eye me-2 font-weight-bold"></i> Xem trước</a>
                                                    <a href="/tao-web/<?=$row['id'];?>" class="btn btn-md btn-primary mb-2 ms-2 w-45 fs-14 text-wrap"><i class="fe fe-shopping-cart me-2"></i> Tạo Ngay - <?=Monney($row['price']);?><sup>đ</sup> </a>
                                                </div>
                                                
                                            </div>
                                        </div>
                                        
                                        
                                        <?php } ?>
                                        
                                    </div>
                                
                                
                                </div>

                            </div>
                            <!-- END ROW -->

                        </div>
                    </div>
                </div>
                
            </div>
            


<?php
include('../cpn/footer.php');
?>