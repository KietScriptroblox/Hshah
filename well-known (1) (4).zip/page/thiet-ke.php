<?php
include('../cpn/header.php');
$query = $connect->query("SELECT * FROM `MauLogo` WHERE `id` = '".$_GET['id']."'")->fetch_array();

if($_GET['id'] != $query['id']){
    echo redirect('/');
}

checkSession();

echo Title("Thanh Toán Dịch Vụ #".$query['id']);
?>


<div class="main-content app-content">
                    <div class="side-app">
                        <!-- CONTAINER -->
                        <div class="main-container container-fluid px-0">
                                
                            <!-- PAGE-HEADER -->
                            <div class="page-header">
                                <div class="page-leftheader">
                                    <h4 class="page-title mb-0 text-primary"> THANH TOÁN DỊCH VỤ #<?=$query['id'];?></h4>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="card">
                                        <div class="card-header">
                                            <h3 class="card-title"> ĐẶT HÀNG </h3>
                                        </div>
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="form-group col-md-12">
                                                    <label> Nhập Chữ </label>
                                                    <input type="text" class="form-control" placeholder="Nhập Chữ" id="name">
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-12">
                                                <button class="btn btn-info" id="btn-submit" onclick="submit()"> Thanh Toán - <span id="price"><?=Monney($query['price']);?></span><sup>đ</sup></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                
                                <div class="col-md-6">
                                    <div class="ibox card">
                                        <div class="card-body">
                                            <div class="ibox-content">
                                                <div class="row mb-3">
                                                    <div class="col-md-12 col-lg-12">
                                                            <h3> Thông Tin Dịch Vụ </h3>
                                                            <div class="mt-5">
                                                                <p> Tên Bản Thiết Kế: <?=$query['name'];?> </p>
                                                                
                                                                <div class="mt-3">
                                                                    <img src="<?=$query['image'];?>" style="width: 100%; max-width: 245px;">
                                                                </div>
                                                                
                                                                <br>
                                                                
                                                                <button class="mt-5 btn btn-danger" onclick="window.location.href='/thiet-ke-logo-banner';"> Chọn Thiết Kế Khác </button>
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                
                            </div>
                            
                            
                        
                        </div>
                    </div>
                </div>
                 </div>
                 
                 
                         
        <script>
            function submit(){
                $('#btn-submit').html('<img src="https://mir-s3-cdn-cf.behance.net/project_modules/disp/04de2e31234507.564a1d23645bf.gif" width="30px">').prop('disabled', true);
                 $.ajax({
                        url: "/api/ajaxs/thanhtoan-thietke.php",
                        method: "POST",
                        data: {
                            id: '<?=$query['id'];?>',
                            name: $("#name").val(),
                            discount: $("#discount").val(),
                        },
                        success: function(response) {
                            var data = JSON.parse(response);
                            
                            swal('Thông Báo', data.message, data.status);
                            
                            $('#btn-submit').html('Thanh Toán - <span id="price"><?=Monney($query['price']);?></span><sup>đ</sup>').prop('disabled', false);
                        }
                    });
            }
        </script>
                
                
<?php
include('../cpn/footer.php');
?>