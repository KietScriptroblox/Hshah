<?php
include('../cpn/header.php');
checkSession();
echo Title("Mã Giảm Giá");
?>

           <div class="main-content app-content">
                    <div class="side-app">
                        <!-- CONTAINER -->
                        <div class="main-container container-fluid px-0">
                                
                            <!-- PAGE-HEADER -->
                            <div class="page-header">
                                <div class="page-leftheader">
                                    <h4 class="page-title mb-0 text-primary"> Mã Giảm Giá </h4>
                                </div>
                            </div>
                            
                           
                       <div class="row">
                                <div class="col-lg-12">
                                    <div class="card">
                                        <div class="card-body">
                                            
                                            <div class="e-table">
                                                <div class="table-responsive">
                                                    <table class="table table-vcenter text-nowrap border mb-0 table-hover" id="invoicedatatable">
                                                        <thead>
                                                            <tr>
                                                                <th></th>
                                                                <th> ID </th>
                                                                <th> Mã </th>
                                                                <th> Giảm Giá </th>
                                                                <th> Lượt Dùng </th>
                                                                <th> Dịch Vụ  </th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            
                                                            <?php
                                                            $response = $connect->query("SELECT * FROM `MaGiamGia` ORDER BY id DESC");
                                                            foreach($response as $row){
                                                                $id+=1;
                                                            ?>
                                                            
                                                            <tr>
                                                                <td class="align-middle w-5">
                                                                    <label class="custom-control custom-checkbox">
                                                                        <input type="checkbox" class="custom-control-input" name="example-checkbox2" value="option2">
                                                                        <span class="custom-control-label"></span>
                                                                    </label>
                                                                </td>
                                                                
                                                                <td class="align-middle">
                                                                    <div class="d-flex">
                                                                        <div class="mt-1">
                                                                            #<?=$id;?>
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                                
                                                                <td class="text-nowrap align-middle">
                                                                   <?=$row['code'];?>
                                                                </td>
                                                             
                                                                <td class="text-nowrap align-middle">
                                                                  <?php if($row['loai'] == 'tien'){ echo Monney($row['amount']).'<sup>đ</sup>'; } else { echo $row['amount'].'%'; } ?> 
                                                                </td>
                                                                
                                                                <td class="text-nowrap align-middle">
                                                                   <?=Monney($row['gioihan'] - $row['luotdung']);?>
                                                                </td>
                                                                
                                                                <td class="text-nowrap align-middle">
                                                                   <?php if($row['service'] == 'host') { echo 'Mua Hosting'; } else if($row['service'] == 'whm') { echo 'Mua Reseller / Master / Alpha'; } else if($row['service'] == 'shop'){ echo 'Thiết Kế Web / Tạo Shop Game'; } else if($row['service'] == 'domain'){ echo 'Mua Tên Miền'; } else if($row['service'] == 'design'){ echo 'Thiết Kế Ảnh'; } ;?>
                                                                </td>
                                                            </tr>
                                                            
                                                            <?php } if($id < 1){ ?>
                                                            
                                                                <td colspan="8" class="text-center"> Không có dữ liệu:( </td>
                                                            
                                                            <?php } ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                       
                        </div>
                        
                    </div>
                </div>


<?php
include('../cpn/footer.php');
?>