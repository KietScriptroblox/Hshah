<?php
include('../cpn/header.php');
$server = $_GET['id'];
$query = file_get_contents("$hostapi/Api/api.php?type=query_server_reseller&uname=$server");
$getName = json_decode($query, true); 

if($getName['uname'] != $server){
    echo swal($getName['uname'], "error");
} 

echo Title("Danh Sách Gói Reseller Máy Chủ ".$getName['name']);
?>



<div class="main-content app-content">
                    <div class="side-app">
                        <div class="main-container container-fluid px-0">
                                
                            <div class="page-header">
                                <div class="page-leftheader">
                                    <h4 class="page-title mb-0 text-primary"> DANH SÁCH GÓI HOSTING <?=inHoaString($getName['name']);?> </h4>
                                </div>
                            </div>
                            
                           
                           
                           <div class="row">
                               
                                     <?php
                                    $getPackage = file_get_contents("$hostapi/Api/api.php?type=get_package_reseller&uname=$server");
                                    $response = json_decode($getPackage, true); 
                                    foreach ($response as $row) {
                                    $id += 1;
                                        ?>
                                        
                                        
                                    <div class="col-xs-6 col-sm-6 col-xl-3 mt-2">
                                        <div class="card shadow-none">
                                            <div class="card-header text-white align-items-center">
                                                <div class="card-title mx-auto text-center">
                                                    <h3 class="text-danger font-weight-semibold mt-3 mb-2"> WHM <?=inHoaString($row['package']);?> </h3>
                                                    <div class="mb fs-13 text-info"> <?=Monney($row['price']);?><sup>đ</sup>/ Tháng </div>
                                                </div>
                                            </div>
                                            
                                            <div class="card-body text-center  pricing">
                                                <ul class="list-unstyled leading-loose">
                                                    <li class="text-dark border-bottom"> Dung Lượng: <strong> <?=$row['dungluong'];?> </strong></li>
                                                    
                                                    <li class="text-dark border-bottom"> <strong> <?=$row['taikhoan'];?> </strong></li>
                                                    
                                                    <li class="text-dark border-bottom"> Máy Chủ: <strong> <?=$getName['name'];?> </strong></li>
                                                    
                                                    <li class="text-dark border-bottom"> Hostname Riêng: <strong> Có Hỗ Trợ </strong></li>
                                                    
                                                    <li class="text-dark border-bottom"> Thời Gian Kích Hoạt: <strong> <?php if($getName['config'] == 'auto'){ echo 'Ngay Lập Tức'; } else { '15 ~ 30 Phút'; } ;?> </strong></li>
                                                    
                                                    
                                                </ul>
                                                <div class="text-center mt-5">
                                                    <a href="/thanhtoan-reseller/<?=$row['id'];?>" class="btn btn-danger"> Mua Ngay </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <?php } ?>
                                    
                                    </div>
                                            
                                            

                        </div>
                    </div>
                </div>



<?php
include('../cpn/footer.php');
?>