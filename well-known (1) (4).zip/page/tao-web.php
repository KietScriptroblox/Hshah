<?php
include('../cpn/header.php');
$query = $connect->query("SELECT * FROM `Products` WHERE `id` = '".$_GET['id']."'")->fetch_array();

if($_GET['id'] != $query['id']){
    echo redirect('/');
}

checkSession();

echo Title("Tạo Trang Web #".$query['id']);
?>


<div class="main-content app-content">
                    <div class="side-app">
                        <!-- CONTAINER -->
                        <div class="main-container container-fluid px-0">
                                
                            <!-- PAGE-HEADER -->
                            <div class="page-header">
                                <div class="page-leftheader">
                                    <h4 class="page-title mb-0 text-primary"> TẠO TRANG WEB #<?=$query['id'];?></h4>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="card">
                                        <div class="card-header">
                                            <h3 class="card-title"> ĐẶT HÀNG </h3>
                                        </div>
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="form-group col-md-6">
                                                    <label>Tên Miền</label>
                                                    <input type="text" class="form-control" placeholder="Nhập tên miền" id="domain">
                                                </div>
                                                
                                                <div class="form-group col-md-6">
                                                    <label> Hạn Dùng </label>
                                                    <select class="form-control" id="hsd" onchange="getPrice()">
                                                        <option value="1"> 1 Tháng </option>
                                                        <option value="3"> 3 Tháng </option>
                                                        <option value="6"> 6 Tháng </option>
                                                        <option value="9"> 9 Tháng </option>
                                                        <option value="12"> 12 Tháng </option>
                                                    </select>
                                                </div>
                                                
                                                
                                                <div class="form-group col-md-6">
                                                    <label> Tài Khoản Admin </label>
                                                    <input type="text" class="form-control" placeholder="Tài Khoản" id="taikhoan">
                                                </div>
                                                
                                                <div class="form-group col-md-6">
                                                    <label> Mật Khẩu Admin </label>
                                                    <input type="text" class="form-control" placeholder="Mật Khẩu" id="matkhau">
                                                </div>
                                                
                                                <div class="form-group col-md-12">
                                                    <label> Mã Giảm Giá (Nếu Có) </label>
                                                    <input type="text" class="form-control" placeholder="Mã Giảm Giá (Nếu Có)" id="discount">
                                                </div>
                                                
                                            </div>
                                            
                                            <div class="col-md-12">
                                                <button class="btn btn-info" id="btn-submit" onclick="submit()"> Thanh Toán - <span id="price">0</span><sup>đ</sup></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                
                                <div class="col-md-6">
                                    <div class="ibox card">
                                        <div class="card-body">
                                            <div class="ibox-content">
                                                <div class="row mb-3">
                                                    <div class="col-md-12 col-lg-12">
                                                            
                                                            <center><img src="<?=$query['image'];?>" width="100%"></center>
                                                            
                                                            <div class="col-lg-12 col-sm-12 col-xs-12 col-xl-12 mt-5">
                                                                <h3 class="mb-3">
                                                                    <a href="javascript:void(0);" class="text-navy">
                                                                        <?=$query['name'];?>
                                                                    </a>
                                                                </h3>
                                                                
                                                                <div>
                                                                    <h5> Mô Tả </h5>
                                                                    <?=$query['description'];?>
                                                               
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                
                            </div>
                            
                            
                        
                        </div>
                    </div>
                </div>
                 </div>
                 
                 
                 
<script>
    window.onload = getPrice;
    
    function getPrice(){
        const price = '<?=$query['price'];?>';
        const hsd = document.getElementById("hsd").value;
        
        const tongtien = price * hsd;
        let vndString = tongtien.toLocaleString('vi-VN', { style: 'currency', currency: 'VND' }); 
        let codeflow = vndString.replace('₫', ''); 
        document.getElementById('price').innerHTML = codeflow;
    }
                            
    function submit(){
        $('#btn-submit').html('<img src="https://mir-s3-cdn-cf.behance.net/project_modules/disp/04de2e31234507.564a1d23645bf.gif" width="30px">').prop('disabled', true);
         $.ajax({
                url: "/api/ajaxs/thanhtoan-web.php",
                method: "POST",
                data: {
                    id: '<?=$query['id'];?>',
                    domain: $("#domain").val(),
                    taikhoan: $("#taikhoan").val(),
                    matkhau: $("#matkhau").val(),
                    hsd: $("#hsd").val(),
                    discount: $("#discount").val(),
                },
                success: function(response) {
                    var data = JSON.parse(response);
                    
                    swal('Thông Báo', data.message, data.status);
                    
                    
                    $('#btn-submit').html('Thanh Toán - <span id="price">0</span><sup>đ</sup>').prop('disabled', false);
                    getPrice();
                }
            });
    }
</script>
                
                
<?php
include('../cpn/footer.php');
?>