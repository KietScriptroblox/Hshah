<?php
include('../cpn/header.php');
echo Title("Kiểm Tra Tên Miền - Bảng Giá Miền");
?>

           <div class="main-content app-content">
                    <div class="side-app">
                        <!-- CONTAINER -->
                        <div class="main-container container-fluid px-0">
                                
                            <!-- PAGE-HEADER -->
                            <div class="page-header">
                                <div class="page-leftheader">
                                    <h4 class="page-title mb-0 text-primary"> Kiểm Tra Tên Miền </h4>
                                </div>
                            </div>
                            
                            
                            <style>
                                .price {
                                    display: block;
                                    margin-top: 10px;
                                }
                                
                                .product {
                                    text-align: center;
                                    margin-bottom: 20px;
                                }
                            </style>
                                                    
                         
                            
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <h3 class="card-title"> Vui Lòng Nhập Tên Miền </h3>
                                        </div>
                                        <div class="card-body">
                                            <div class="row">
                                                <input class="form-control col-md-12" placeholder="Search your domain" id="domain">
                                            </div>
                        
                                            <center style="padding-top: 8px;">
                                                <button class="btn btn-primary" onclick="whoiGet()" id="WhoisDomain"> Tìm Kiếm </button>
                                            </center>
                                    </div>
                                </div>
                            </div>
                        </div>
                            
                            <div id="result-domain">
                                <h3> Bảng Giá Tên Miền </h3>
                                <center><div class="row">
                                    
                                    <?php
                                    $data = $connect->query("SELECT * FROM `DomainPackages` WHERE `value` = 'on'");
                                    foreach($data as $row){
                                    ?>
                                    
                                        <div class="col-lg-3 mt-2">
                                        <div class="card card-body">
                                        <div class="mb-4 align-items-center">
                                        <center>
                                        <img src="<?=$row['image'];?>" alt="" style="max-width: 80px;">
                                        </center>
                                        </div>
                                        <h6 class="mb-1 text-center"> <?=Monney($row['price']);?> <sup>đ</sup>
                                        </h6>
                                        <p class="card-text text-center"> TÊN MIỀN .<?=inHoaString($row['name']);?> </p>
                                        </div>
                                        </div>
                                    
                                    <?php
                                    }
                                    ?>
                                        
                                </div> </center>
                                
                                
                            </div>
                        </div>
                        
                    </div>
                </div>


            <script>
                  function whoiGet(){
                      $('#WhoisDomain').html('<i class="fa fa-spinner fa-spin"></i>').prop('disabled', true);
                       $.ajax({
                            url: "/api/ajaxs/whoisdomain.php",
                            method: "POST",
                            data: {
                                domain: $("#domain").val()
                            },
                            success: function(response) {
                                document.getElementById('result-domain').innerHTML = `
                                    <div class="block-content">
                                      <div class="table-responsive">
                                        <table class="table table-borderless table-striped table-vcenter fs-sm">
                                          <thead>
                                            <tr>
                                              <th> Trạng Thái </th>
                                              <th class="text-center" style="width: 100px;"> Domain </th>
                                              <th class="text-center"> Giá Tiền </th>
                                              <th class="text-center"> Hành Động </th>
                                            </tr>
                                          </thead>
                                          <tbody id="listdomain">
                                          </tbody>
                                        </table>
            
                                      </div>
                                      
                                    </div>
                                    `;
                                    
                                    var element = document.getElementById('result-domain');
                                    if (element) {
                                        element.classList.add('card');
                                    }
                                    
                                    $("#listdomain").html(response);
                                    
                                    
                                $('#WhoisDomain').html('<i class="fa fa-fw opacity-50 fa-search"></i> Kiểm tra').prop('disabled', false);
                            }
                        });
                  }
                  
                  
                  function toUrl(url){
                      document.getElementById("domains").value = url;
                      document.getElementById("tourl").submit();
                  }
                 
              </script>
              
              
              <form id="tourl" action="/mua-mien" method="post">
                  <input type="hidden" name="domain" id="domains">
              </form>
  
<?php
include('../cpn/footer.php');
?>