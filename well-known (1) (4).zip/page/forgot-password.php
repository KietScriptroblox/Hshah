<?php
include('../cpn/config.php');
include('../cpn/components/head.php');
?>
<script>
    document.title = 'Đặt Lại Mật Khẩu';
</script>

<body class="login-page">

		<div id="global-loader" style="display: none;">
			<img src="/build/assets/images/svgs/loader.svg" alt="loader">
		</div>
		<!--- END GLOBAL LOADER -->

		<!-- PAGE -->
                                
        <div class="register-2">
                    
			<div class="page">
				<div class="page-content">
					<div class="container">
						<div class="row">
							<div class="col mx-auto mt-5">
								<div class="row justify-content-center">
									<div class="col-lg-4 col-md-6 col-sm-8">
										<div class="text-center mb-6">
											<a href="/"><img src="<?=$system32['logo'];?>" class="header-brand-img" alt="Logo"></a>
										</div>
										<div class="card">
											<div class="card-body">
												<div class="text-center mb-3">
													<h3 class="mb-2"> Đặt Lại Mật Khẩu </h3>
													<p> Vui lòng nhập email tài khoản của bạn để khôi phục tài khoản! </p>
												</div>
												<form class="mt-5">
													<div class="input-group mb-4">
															<div class="input-group-text">
																<i class="fe fe-mail"></i>
															</div>
														<input type="text" class="form-control" placeholder="Email tài khoản" id="email">
													</div>

													<div class="form-group text-center mb-3">
													    <p class="text-success" id="message"></p>
														<a id="btn-submit" onclick="ForgotPassword()" class="btn btn-primary w-100 br-7"> Đặt lại mật khẩu </a>
													</div>
													
													<div class="form-group fs-12 text-center">
														By Clicking Send ,You agree to our  <a href="/terms" class="font-weight-bold">Terms &amp; Conditions</a> and have read and acknowledge our  <a href="/terms" class="font-weight-bold">Privacy &amp; Services.</a>
													</div>
													
												</form>
											</div>
										</div>
										
										<div class="text-center register-icons">
											<div class="small text-white mb-4">Login using with</div>
											<button class="btn bg-white-50  text-white-50 font-weight-semibold w-12 google me-2" type="button"><i class="fa fa-google"></i></button>
											<button class="btn bg-white-50  text-white-50 font-weight-semibold  w-12 facebook me-2" type="button"><i class="fa fa-facebook-f"></i></button>
											<button class="btn bg-white-50  text-white-50 font-weight-semibold w-12 twitter me-2" type="button"><i class="fa fa-twitter"></i></button>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

        
        

<script>
    function ForgotPassword(){
        $('#btn-submit').html('<i class="fa fa-spinner fa-spin"></i>').prop('disabled', true);
        $.ajax({
            url: "/api/ajaxs/auth.php",
            method: "POST",
            data: {
                type: 'forgotpassword',
                email: $("#email").val(),
            },
            success: function(response) {
                var data = JSON.parse(response);
             
                if(data.status == 'success'){
                    document.getElementById("message").innerHTML = `<center><p></p>
                  <strong> Chúng tôi đã gửi một mã đến email của bạn?, <a href="/login" class="text-primary"> Đăng Nhập Tài Khoản </a></strong>
                </center>`;
                } else {
                    swal('Thông Báo', data.message, data.status);
                }
                
                $('#btn-submit').html('Gửi Mã').prop('disabled', false);
            }
        });
    }
</script>

        <script src="/build/assets/plugins/jquery/jquery.min.js"></script>
        <script src="/build/assets/plugins/bootstrap/popper.min.js"></script>
        <script src="/build/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
        <script src="/build/assets/plugins/p-scrollbar/p-scrollbar.js"></script>
        <script src="/build/assets/plugins/bootstrap/bootstrap-show-password.min.js"></script>
        <link rel="modulepreload" href="/build/assets/themeColors.2c059b7b.js" /><link rel="modulepreload" href="/build/assets/apexcharts.common.4772fa83.js" /><script type="module" src="/build/assets/themeColors.2c059b7b.js"></script>
		<link rel="modulepreload" href="/build/assets/app.f4590aff.js" /><link rel="modulepreload" href="/build/assets/apexcharts.common.4772fa83.js" /><script type="module" src="/build/assets/app.f4590aff.js"></script>
	</body>
</html>
