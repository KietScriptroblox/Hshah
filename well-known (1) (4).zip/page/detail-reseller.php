<?php
include('../cpn/header.php');
$id = $_GET['id']; 

$query = $connect->query("SELECT * FROM `DanhSachReseller` WHERE `id` = '$id' AND `username` = '".$getUser['username']."'")->fetch_array();
$apiQuery = json_decode(file_get_contents("$hostapi/Api/api.php?type=info_reseller&apikey=$apikey&domain=".$query['domain']), true);
$package = json_decode(file_get_contents("$hostapi/Api/api.php?type=getpackage_reseller2&package=".$query['package']), true);
$getName = json_decode(file_get_contents("$hostapi/Api/api.php?type=query_server_reseller&uname=".$query['server']), true);

if($_GET['id'] != $query['id']){
    echo redirect('/');
} else if($getUser['username'] != $query['username']){
    echo swal("Bạn không có quyền quản lý dịch vụ này!","error");
    echo redirect('/');
}

echo Title("Chi tiết dịch vụ - #".inHoaString($query['domain']));
?>



<div class="main-content app-content">
                    <div class="side-app">
                        <div class="main-container container-fluid px-0">
                             
                            <div class="page-header">
                                <div class="page-leftheader">
                                    <h4 class="page-title mb-0 text-primary"> Chi Tiết Dịch Vụ - #<?=($query['id']);?> </h4>
                                </div>
                            </div>
  
                            <div class="row">
                                
                                <div class="col-md-12 col-lg-4">
                                    <div class="card">
                                        <div class="card-header">
                                            <h3 class="card-title"> Thao Tác Nhanh </h3>
                                        </div>
                                        
                                        
                                        <div class="card-body">
                                            <div class="btn-list">
                                                <div class="row">
                                                    <a <?php if($apiQuery['status_r'] == 1){ ?> onclick="window.open('<?=$getName['hostname'];?>:2087/login/?user=<?=$apiQuery['taikhoan'];?>&pass=<?=$apiQuery['matkhau'];?>')" <?php } else { ?> onclick="ErrorStatus()" <?php } ?> class="btn badge-gradient-danger mt-2 text-light"> Login To WHM </a>
                                                    <a <?php if($apiQuery['status_r'] == 1){ ?> data-bs-toggle="modal" data-bs-target="#changepassword" <?php } else { ?> onclick="ErrorStatus()" <?php } ?> class="btn btn-primary col-12 mt-3"> Đổi Mật Khẩu </a>
                                                    <a <?php if($apiQuery['status_r'] == 1 || $apiQuery['status_r'] == 4){ ?> data-bs-toggle="modal" data-bs-target="#giahan" <?php } else { ?> onclick="ErrorStatus()" <?php } ?> class="btn btn-secondary col-12 mt-3"> Gia Hạn </a>
                                                    <a onclick="SwalChamDut()" class="btn btn-danger col-12 mt-3"> Chấm Dứt </a>
                                            </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                 
                                
                                <div class="col-lg-8">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="row">

                                                <div class="col-lg-12">
                                                        <div class="col-md-9 d-block mx-auto">
                                                            <h3 class="text-center">#WHM <?=inHoaString($query['package']);?></h3>
                                                            <p class="text-muted"> Nếu dịch vụ hết hạn sau 3 ngày bạn không gia hạn dịch vụ sẽ bị xóa vĩnh viễn, <strong class="text-danger">không thể khôi phục</strong>! </p>
                                                            
                                                            <div class="mt-5 text-center">
                                                                <h3 class=" text-danger"> Thông tin chi tiết </h3>
                                                                
                                                                <ul>
                                                                    <p> Link Đăng Nhập: <a href="<?=$getName['hostname'];?>:2087" class="text-primary" target="_blank"> <?=$getName['hostname'];?>:2087 </a> </p>
                                                                    <p> Tên Miền: <a href="https://<?=$apiQuery['domain'];?>" class="text-primary"> <?=inHoaString($apiQuery['domain']);?> </a></p>
                                                                    <p> Tài Khoản: <span><?=$apiQuery['taikhoan'];?></span></p>
                                                                    <p> Mật Khẩu: <span><?=$apiQuery['matkhau'];?></span></p>
                                                                    <p> IP: <span><?=$getName['ip'];?></span></p>
                                                                    <p> Nameserver: <strong class="text-danger"> <?=inHoaString($getName['ns1']);?>,<?=inHoaString($getName['ns2']);?> </strong> </p>
                                                                    <p></p>
                                                                    <p></p>
                                                                    
                                                                    <p> Email: <span> <?=$apiQuery['email'];?> </span></p>
                                                                    <p> Ngày Mua: <span><?=ToTime($apiQuery['time']);?></span></p>
                                                                    <p> Ngày Hết Hạn: <span><?=ToTime($apiQuery['orvertime']);?></span></p>
                                                                    <p> Trạng Thái: <span> <?=StatusHost($apiQuery['status_r']);?> </span></p>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                
                                
                                
                            </div>
                        </div>
                    </div>
                </div>
                

<!-- Modal -->

  <?php if($apiQuery['status_r'] == 1){ ?>
  
  <div class="modal fade effect-flip-horizontal" id="changepassword" aria-modal="true" role="dialog">
                <div class="modal-dialog modal-dialog-centered text-center" role="document">
                    <div class="modal-content modal-content-demo">
                        <div class="modal-header">
                            <h6 class="modal-title"> Đổi Mật Khẩu </h6><button aria-label="Close" class="btn-close" data-bs-dismiss="modal" type="button"><span aria-hidden="true">×</span></button>
                        </div>
                        <div class="modal-body">
                            <div class="input-group">
                                <input type="text" class="form-control form-control-alt" id="passh" placeholder="Nhập Mật Khẩu Mới">
                                <span class="input-group-text input-group-text-alt">
                                 <button class="btn btn-danger" onclick="CreatePassword()"> Tạo Ngẫu Nhiên </button>
                                </span>
                             </div>

                            <div class="text-center" style="padding-top: 25px;" id="password_message">
                            </div>
                        </div>
                        
            
                        <div class="modal-footer">
                            <button onclick="ChangePassword()" id="ChangePassword" class="btn btn-sm btn-primary"> Đổi Mật Khẩu </button>
                            <button class="btn btn-sm btn-secondary" data-bs-dismiss="modal" type="button">Close</button>
                        </div>
                    </div>
                </div>
            </div>
            
  
   <?php } if($apiQuery['status_r'] == 1 || $apiQuery['status_r'] == 4){ ?>
   
                   <div class="modal fade effect-flip-horizontal" id="giahan" aria-modal="true" role="dialog">
                    <div class="modal-dialog modal-dialog-centered text-center" role="document">
                        <div class="modal-content modal-content-demo">
                            <div class="modal-header">
                                <h6 class="modal-title"> Gia Hạn Dịch Vụ </h6><button aria-label="Close" class="btn-close" data-bs-dismiss="modal" type="button"><span aria-hidden="true">×</span></button>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <select class="form-control" id="hsd">
                                        <option value="1"> 1 Tháng (<?=Monney($package['price'] * 1);?><sup>đ</sup>) </option>
                                        <option value="3"> 3 Tháng (<?=Monney($package['price'] * 3);?><sup>đ</sup>) </option>
                                        <option value="6"> 6 Tháng (<?=Monney($package['price'] * 6);?><sup>đ</sup>) </option>
                                        <option value="9"> 9 Tháng (<?=Monney($package['price'] * 9);?><sup>đ</sup>) </option>
                                        <option value="12"> 12 Tháng (<?=Monney($package['price'] * 12);?><sup>đ</sup>) </option>
                                    </select>
                                </div>
                                
                            </div>
                            
                            <div class="text-center" id="message6" width="100px">
                                
                            </div>
                            
                            <div class="modal-footer">
                                <button class="btn btn-primary" id="ThanhToan" type="button" onclick="ThanhToan()"> Thanh Toán </button>
                                <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
  
       <?php } ?>
  
<!-- Hết Gòi -->


<script>

<?php if($apiQuery['status_r'] == 1){ ?>

    function CreatePassword(){
        function generateRandomPassword(length) {
              const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#^&()_+";
              let password = "";
              
              for (let i = 0; i < length; i++) {
                const randomIndex = Math.floor(Math.random() * charset.length);
                password += charset[randomIndex];
              }
              
              return password;
            }
            
            const randomPassword = generateRandomPassword(12); 
            
            document.getElementById("passh").value = randomPassword;

    }
    
    function ChangePassword(){
        $('#ChangePassword').html('<i class="fa fa-spinner fa-spin"></i>').prop('disabled', true);
        $.ajax({
            url: "/api/ajaxs/whm.php",
            method: "POST",
            data: {
               id: '<?=$query['id'];?>',
               password: $("#passh").val(),
               type: 'changepassword',
            },
            success: function(response) {
                var data = JSON.parse(response);
                
                if(data.status == 'success'){
                    var msg = `<strong class="text-success"> ${data.message} </strong>`;
                } else {
                    var msg = `<strong class="text-danger"> ${data.message} </strong>`;
                }
                
                 $("#password_message").html(msg);
                 
             $('#ChangePassword').html('Đổi Mật Khẩu').prop('disabled', false);
            }
        });
    }


      
    <?php } if($query['status_r'] == 1 || 4){ ?>

      function ThanhToan(){
            $("#ThanhToan").html('<i class="fa fa-spinner fa-spin"></i>');
            $.ajax({
                url: "/api/ajaxs/whm.php",
                method: "POST",
                data: {
                   id: '<?=$id;?>',
                   hsd: $("#hsd").val(),
                   type: 'giahan'
                },
                success: function(response) {
                    
                    var data = JSON.parse(response);
                
                if(data.status == 'success'){
                    var msg = `<strong class="text-success"> ${data.message} </strong>`;
                } else {
                    var msg = `<strong class="text-danger"> ${data.message} </strong>`;
                }
                
                 $("#message6").html(msg);
                 
                 $("#ThanhToan").html('Thanh Toán');
                }
            });
      }
    
      <?php } ?>
      
      function ErrorStatus(){
          swal('Thông Báo','Tính Năng Chỉ Dành Cho Dịch Vụ Hoạt Động!','warning');
      }
      
       function SwalChamDut(){
        swal({
          title: "Xác Nhận",
          text: "Bạn Có Chắc Muốn Xóa Dịch Vụ?",
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
        .then((willDelete) => {
          if (willDelete) {
              document.getElementById("submitDelete").submit();
              swal("Tạo Lệnh Chấm Dứt Thành Công, Vui Lòng Đợi", {
              icon: "success",
            });
          }
        });
    }
</script>
                            
                            
<form action="" method="post" id="submitDelete"><input name="deleteTrue" type="hidden" value="cyberlux.vn"></form>      

    
<?php
if(isset($_POST['deleteTrue'])){
    
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, "$hostapi/Api/api.php?type=delete_reseller&domain=".$query['domain']."&apikey=$apikey");
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response_data = curl_exec($curl);
    
    if (curl_errno($curl)) {
        echo json_encode(['message' => 'cURL Error: ' . curl_error($curl), 'status' => 'error']);
    } else {
        $response = json_decode($response_data, true);
        if($response['status'] == 'success'){
            $connect->query("DELETE FROM `DanhSachReseller` WHERE `id` = '$id'");
            echo swal($response['message'], $response['status']);
            echo redirect('/quan-ly-reseller');
        } else {
            echo swal($response['message'], $response['status']);
        }
    }
    
    curl_close($curl);
        
}
include('../cpn/footer.php');
?>