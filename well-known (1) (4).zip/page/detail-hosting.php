<?php
include('../cpn/header.php');
$id = $_GET['id']; 
$query = $connect->query("SELECT * FROM `DanhSachHosting` WHERE `id` = '".$_GET['id']."' AND `username` = '".$getUser['username']."'")->fetch_array();
$getName = $connect->query("SELECT * FROM `ServerName` WHERE `uname` = '".$query['server']."'")->fetch_array();
$getPack = $connect->query("SELECT * FROM `PackageHosting` WHERE `package` = '".$query['package']."'")->fetch_array();

if($_GET['id'] != $query['id']){
    echo redirect('/');
} else if($getUser['username'] != $query['username']){
    echo swal("Bạn không có quyền quản lý dịch vụ này!","error");
    echo redirect('/');
}

echo Title("Chi tiết dịch vụ - #".inHoaString($query['domain']));
?>


<div class="main-content app-content">
                    <div class="side-app">
                        <div class="main-container container-fluid px-0">
                             
                            <div class="page-header">
                                <div class="page-leftheader">
                                    <h4 class="page-title mb-0 text-primary"> Chi Tiết Dịch Vụ - #<?=($query['id']);?> </h4>
                                </div>
                            </div>
  
                            <div class="row">
                                
                                <div class="col-md-12 col-lg-4">
                                    <div class="card">
                                        <div class="card-header">
                                            <h3 class="card-title"> Thao Tác Nhanh </h3>
                                        </div>
                                        
                                        
                                        <div class="card-body">
                                            <div class="btn-list">
                                                <div class="row">
                                                    <a <?php if($query['status'] == 1){ ?> onclick="window.open('<?=$getName['hostname'];?>:2083/login/?user=<?=$query['taikhoan'];?>&pass=<?=$query['matkhau'];?>')" <?php } else { ?> onclick="ErrorStatus()" <?php } ?> class="btn badge-gradient-danger mt-2 text-light"> Login To Cpanel </a>
                                                    <a <?php if($query['status'] == 1){ ?> data-bs-toggle="modal" data-bs-target="#changepassword" <?php } else { ?> onclick="ErrorStatus()" <?php } ?> class="btn btn-primary col-12 mt-3"> Đổi Mật Khẩu </a>
                                                    <a <?php if($query['status'] == 1 || $query['status'] == 4){ ?> data-bs-toggle="modal" data-bs-target="#giahan" <?php } else { ?> onclick="ErrorStatus()" <?php } ?> class="btn btn-secondary col-12 mt-3"> Gia Hạn </a>
                                                    <a <?php if($query['status'] == 1){ ?>data-bs-toggle="modal" data-bs-target="#upgrade" <?php } else { ?> onclick="ErrorStatus()" <?php } ?> class="btn btn-success col-12 mt-3"> Nâng Cấp </a>
                                                    <a <?php if($query['status'] == 1){ ?>data-bs-toggle="modal" data-bs-target="#change_domain" onclick="LoadDomains()" <?php } else { ?> onclick="ErrorStatus()" <?php } ?> class="btn btn-info col-12 mt-3"> Đổi Miền Chính </a>
                                                    <a <?php if($query['status'] == 1){ ?>data-bs-toggle="modal" data-bs-target="#reset" <?php } else { ?> onclick="ErrorStatus()" <?php } ?> class="btn btn-warning col-12 mt-3"> Reset Dịch Vụ </a>
                                                    <a onclick="SwalChamDut()" class="btn btn-danger col-12 mt-3"> Chấm Dứt </a>
                                            </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                 
                                
                                <div class="col-lg-8">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="row">

                                                <div class="col-lg-12">
                                                        <div class="col-md-9 d-block mx-auto">
                                                            <h3 class="text-center">#CPANEL <?=inHoaString($query['package']);?></h3>
                                                            <p class="text-muted"> Nếu dịch vụ hết hạn sau 3 ngày bạn không gia hạn dịch vụ sẽ bị xóa vĩnh viễn, <strong class="text-danger">không thể khôi phục</strong>! </p>
                                                            
                                                            <div class="mt-5 text-center">
                                                                <h3 class=" text-danger"> Thông tin chi tiết </h3>
                                                                
                                                                <ul>
                                                                    <p> Link Đăng Nhập: <a href="<?=$getName['hostname'];?>:2083" class="text-primary" target="_blank"> <?=$getName['hostname'];?>:2083 </a> </p>
                                                                    <p> Tên Miền: <a href="https://<?=$query['domain'];?>" class="text-primary"> <?=inHoaString($query['domain']);?> </a></p>
                                                                    <p> Tài Khoản: <span><?=$query['taikhoan'];?></span></p>
                                                                    <p> Mật Khẩu: <span><?=$query['matkhau'];?></span></p>
                                                                    <p> IP: <span><?=$getName['ip'];?></span></p>
                                                                    <p> Nameserver: <strong class="text-danger"> <?=$getName['nameserver1'];?>,<?=$getName['nameserver2'];?> </strong> </p>
                                                                    <p></p>
                                                                    <p></p>
                                                                    
                                                                    <p> Email: <span> <?=$query['email'];?> </span></p>
                                                                    <p> Ngày Mua: <span><?=ToTime($query['time']);?></span></p>
                                                                    <p> Ngày Hết Hạn: <span><?=ToTime($query['orvertime']);?></span></p>
                                                                    <p> Trạng Thái: <span> <?=StatusHost($query['status']);?> </span></p>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                
                                
                                
                            </div>
                        </div>
                    </div>
                </div>
                
            
                        
                        
                        
<form action="" method="post" id="submitDelete"><input name="delete" value="true" type="hidden"></form>

<?php 
if(isset($_POST['delete']) && $_POST['delete'] == 'true'){
        $query = $getName['hostname'].':2087/json-api/removeacct?api.version=1&user='.$query['taikhoan'].'&password='.$query['matkhau'].'&enabledigest=0&db_pass_update=1'; 
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0); 
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
        curl_setopt($curl, CURLOPT_HEADER,0); 
        curl_setopt($curl, CURLOPT_RETURNTRANSFER,1); 
        $header[0] = "Authorization: Basic " . base64_encode($getName['whmusername'].":".$getName['whmpassword']) . "\n\r";
        curl_setopt($curl, CURLOPT_HTTPHEADER, $header); 
        curl_setopt($curl, CURLOPT_URL, $query); 
        $result = curl_exec($curl); 
        if ($result == false) {
            echo swal('Không Thể Kết Nối Đến Cpanel','error');
        } else {
            $connect->query("DELETE FROM `DanhSachHosting` WHERE `id` = '$id'");
            echo swal('Chấm Dứt Dịch Vụ Thành Công','success');
            echo redirect('');
        }
        curl_close($curl); 
  }
  
?>

<!-- Modal -->

  <?php if($query['status'] == 1){ ?>
  
  <div class="modal fade effect-flip-horizontal" id="changepassword" aria-modal="true" role="dialog">
                <div class="modal-dialog modal-dialog-centered text-center" role="document">
                    <div class="modal-content modal-content-demo">
                        <div class="modal-header">
                            <h6 class="modal-title"> Đổi Mật Khẩu </h6><button aria-label="Close" class="btn-close" data-bs-dismiss="modal" type="button"><span aria-hidden="true">×</span></button>
                        </div>
                        <div class="modal-body">
                            <div class="input-group">
                                <input type="text" class="form-control form-control-alt" id="passh" placeholder="Nhập Mật Khẩu Mới">
                                <span class="input-group-text input-group-text-alt">
                                 <button class="btn btn-danger" onclick="CreatePassword()"> Tạo Ngẫu Nhiên </button>
                                </span>
                             </div>

                            <div class="text-center" style="padding-top: 25px;" id="message5">
                            </div>
                        </div>
                        
            
                        <div class="modal-footer">
                            <button onclick="ChangePassword()" id="ChangePassword" class="btn btn-sm btn-primary"> Đổi Mật Khẩu </button>
                            <button class="btn btn-sm btn-secondary" data-bs-dismiss="modal" type="button">Close</button>
                        </div>
                    </div>
                </div>
            </div>
            
  
   <?php } if($query['status'] == 1 || $query['status'] == 4){ ?>
   
                   <div class="modal fade effect-flip-horizontal" id="giahan" aria-modal="true" role="dialog">
                    <div class="modal-dialog modal-dialog-centered text-center" role="document">
                        <div class="modal-content modal-content-demo">
                            <div class="modal-header">
                                <h6 class="modal-title"> Gia Hạn Dịch Vụ </h6><button aria-label="Close" class="btn-close" data-bs-dismiss="modal" type="button"><span aria-hidden="true">×</span></button>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <select class="form-control" id="hsd" onchange="CheckTime()">
                                        <option value="1"> 1 Tháng </option>
                                        <option value="3"> 3 Tháng </option>
                                        <option value="6"> 6 Tháng </option>
                                        <option value="9"> 9 Tháng </option>
                                        <option value="12"> 12 Tháng </option>
                                    </select>
                                </div>
                                
                            </div>
                            
                            <div class="text-center" id="message6" width="100px">
                                
                            </div>
                            
                            <div class="modal-footer">
                                <button class="btn btn-primary" id="ThanhToan" type="button" onclick="ThanhToan()"> Thanh Toán - <span id="price">0</span><sup>đ</sup></button>
                                <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
  
   <?php } if($query['status'] == 1){ ?>
   
   
   <div class="modal fade effect-flip-horizontal" id="upgrade" aria-modal="true" role="dialog">
        <div class="modal-dialog modal-dialog-centered text-center" role="document">
            <div class="modal-content modal-content-demo">
                <div class="modal-header">
                    <h6 class="modal-title"> Nâng Cấp Dịch Vụ </h6><button aria-label="Close" class="btn-close" data-bs-dismiss="modal" type="button"><span aria-hidden="true">×</span></button>
                </div>
                
                <div class="modal-body">
                    <div class="form-group">
                        <select class="form-control form-control-alt" id="package_upgrade">
                           <?php
                           $hsd = tinhNgay($query['time'], $query['orvertime']);
                           $tienConLai  = TruTienDichVu($query['time'], $getPack['price'], $hsd);
                           $getPrice = $getPack['price'];
                           $res = $connect->query("SELECT * FROM PackageHosting WHERE server = '".$getName['uname']."' AND price > $getPrice");
                           foreach($res as $row){
                               $id+=1;
                           ?>
                           
                           <option value="<?=$row['id'];?>"> <?=inHoaString($row['package']);?> (<?=Monney($row['price'] - $tienConLai);?> <sup>đ</sup>) </option>
                           
                           <?php } if($id == 0){ ?>
                           
                            <option value=""> Hiện không có gói nào:( </option>
                            
                           <?php } ?>
                           
                       </select>
                    </div>
                    
                </div>
                
                 <div class="text-center" style="padding-top: 25px;" id="message7"> </div>

                
                <div class="modal-footer">
                    <button class="btn btn-primary" onclick="NangCap()" id="NangCap" > Thanh Toán </button>
                    <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">Close</button>
                </div>
            </div>
        </div>
    </div>
    
                
   <?php } if($query['status'] == 1){ ?>
   
  
  <div class="modal fade effect-flip-horizontal" id="reset" aria-modal="true" role="dialog">
                <div class="modal-dialog modal-dialog-centered text-center" role="document">
                    <div class="modal-content modal-content-demo">
                        <div class="modal-header">
                            <h6 class="modal-title">Đặt Lại Hosting </h6><button aria-label="Close" class="btn-close" data-bs-dismiss="modal" type="button"><span aria-hidden="true">×</span></button>
                        </div>
                        <div class="modal-body">
                            <form action="" method="post">
                            <div class="input-group">
                                <input type="text" class="form-control form-control-alt" name="password" placeholder="Mật Khẩu Tài Khoản">
                             </div>
                        </div>
                        
            
                        <div class="modal-footer">
                            <button type="submit" name="reset_cp" class="btn btn-sm btn-primary"> Đặt Lại Dịch Vụ </button>
                            <button class="btn btn-sm btn-secondary" data-bs-dismiss="modal" type="button">Close</button>
                        </div>
                        </form>
                        
                    </div>
                </div>
            </div>
  
  <form action="" method="post" id="submit_reset">
    <input name="taolai" value="true" type="hidden">
</form>

  
  <?php
  if(isset($_POST['reset_cp'])){
      $password = $_POST['password'];
      if(md5($password) == $getUser['password']){
          
            $query = $getName['hostname'].':2087/json-api/removeacct?api.version=1&user='.$query['taikhoan'].'&password='.$query['matkhau'].'&enabledigest=0&db_pass_update=1'; 
            $curl = curl_init(); 
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0); 
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
            curl_setopt($curl, CURLOPT_HEADER,0); 
            curl_setopt($curl, CURLOPT_RETURNTRANSFER,1); 
            $header[0] = "Authorization: Basic " . base64_encode($getName['whmusername'].":".$getName['whmpassword']) . "\n\r";
            curl_setopt($curl, CURLOPT_HTTPHEADER, $header);  
            curl_setopt($curl, CURLOPT_URL, $query);
            $result = curl_exec($curl); 
            
            if ($result == false) {
                $message_reset = 'Không Thể Gửi Yêu Cầu Tới Cpanel';
                 echo swal($message_reset,'error');
            } else {
                 echo swal('Đang Tiến Hành Tạo Lại, Vui Lòng Đợi','success');
                 echo '<script>document.getElementById("submit_reset").submit(); </script>';
            }
            curl_close($curl);
            
      } else {
          $message_reset = 'Sai Mật Khẩu, Vui Lòng Thử Lại';
          echo swal($message_reset,'error');
      }
  }
  
  if(isset($_POST['taolai'])){
    $query = $getName['hostname'].':2087/json-api/createacct?api.version=1&username='.$query['taikhoan'].'&domain='.$query['domain'].'&plan='.$getName['whmusername'].'_'.$query['package'].'&featurelist=default&password='.$query['matkhau'].'&ip=n&cgi=1&hasshell=1&contactemail='.$query['email'].'&cpmod=paper_lantern&language=vi'; 
    $curl = curl_init(); 
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0); 
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0); 
    curl_setopt($curl, CURLOPT_HEADER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1); 
    $header[0] = "Authorization: Basic " . base64_encode($getName['whmusername'].":".$getName['whmpassword']) . "\n\r";
    curl_setopt($curl, CURLOPT_HTTPHEADER, $header); 
    curl_setopt($curl, CURLOPT_URL, $query);
    $result = curl_exec($curl); 
    if ($result == false) {
        $message_reset = 'Không Thể Gửi Yêu Cầu Tới Cpanel';
        echo swal($message_reset,'error');
    } else {
        echo swal('Đặt Lại Dịch Vụ Thành Công','success');
        echo redirect('');
    }
    curl_close($curl);   
  }
  ?>
  
  
  
<?php } if($query['status'] == 1){ ?>
  
  
  
   <div class="modal fade effect-flip-horizontal" id="change_domain" aria-modal="true" role="dialog">
        <div class="modal-dialog modal-dialog-centered text-center" role="document">
            <div class="modal-content modal-content-demo">
                <div class="modal-header">
                    <h6 class="modal-title"> Thêm Miền Con </h6><button aria-label="Close" class="btn-close" data-bs-dismiss="modal" type="button"><span aria-hidden="true">×</span></button>
                </div>
                
                <div class="modal-body">
                    <div class="form-group">
                        <input class="form-control" id="domain" placeholder="Nhập Miền">
                    </div>
                    
                    
                    <div class="form-group">
                        <select id="rootdomain" class="form-control"><option> Đang Lấy Dữ Liệu </option></select>
                    </div>


                 <div class="text-center" style="padding-top: 25px;" id="message8"> </div>
                
                <div class="modal-footer">
                    <button class="btn btn-primary" onclick="changeDomain()" id="changeDomain" > Thanh Toán </button>
                    <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">Close</button>
                </div>
            </div>
        </div>
    </div>
    
  
  
<?php } ?>
  
  
  
<!-- Hết Gòi -->


<script>

<?php if($query['status'] == 1){ ?>

    function CreatePassword(){
        function generateRandomPassword(length) {
              const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#^&()_+";
              let password = "";
              
              for (let i = 0; i < length; i++) {
                const randomIndex = Math.floor(Math.random() * charset.length);
                password += charset[randomIndex];
              }
              
              return password;
            }
            
            const randomPassword = generateRandomPassword(12); 
            
            document.getElementById("passh").value = randomPassword;

    }
    
    function ChangePassword(){
        $('#ChangePassword').html('<i class="fa fa-spinner fa-spin"></i>').prop('disabled', true);
        $.ajax({
            url: "/api/ajaxs/cpanel.php",
            method: "POST",
            data: {
               id: '<?=$query['id'];?>',
               pass: $("#passh").val(),
               whmusername: '<?=$getName['whmusername'];?>',
               whmpassword: '<?=$getName['whmpassword'];?>',
               hostname: '<?=$getName['hostname'];?>',
               type: 'changepassword',
            },
            success: function(response) {
             $("#message5").html(response);
             $('#ChangePassword').html('Đổi Mật Khẩu').prop('disabled', false);
            }
        });
    }
    
    
    function NangCap(){
          $('#NangCap').html('<i class="fa fa-spinner fa-spin"></i>').prop('disabled', true);
           $.ajax({
                url: "/api/ajaxs/cpanel.php",
                method: "POST",
                data: {
                   id: '<?=$query['id'];?>',
                   packagee: $("#package_upgrade").val(),
                   type: 'upgrade'
                },
                success: function(response) {
                    $("#message7").html(response);
                     $('#NangCap').html('Thanh Toán').prop('disabled', false);
                }
            });
      }
      
      
      function LoadDomains(){
        $("#listdomain").html('<i class="fa fa-spinner fa-spin"></i>');
        $.ajax({
            url: "/api/LoadCpanel.php",
            method: "POST",
            data: {
               username: '<?=$query['taikhoan'];?>',
               password: '<?=$query['matkhau'];?>',
               ip: '<?=$getName['ip'];?>',
               type: 'loaddomain'
            },
            success: function(response) {
             $("#rootdomain").html(response);
            }
        });
      }
        
      
      function changeDomain(){
        $('#changeDomain').html('<i class="fa fa-spinner fa-spin"></i>').prop('disabled', true);
        $.ajax({
            url: "/api/ajaxs/cpanel.php",
            method: "POST",
            data: {
               username: '<?=$query['taikhoan'];?>',
               password: '<?=$query['matkhau'];?>',
               ip: '<?=$getName['ip'];?>',
               domain: $("#domain").val(),
               rootdomain: $("#rootdomain").val(),
               type: 'addsubdomain',
            },
            success: function(response) {
             $("#message8").html(response);
             $('#changeDomain').html('Thêm Miền Con').prop('disabled', false);
            }
        });
    }
      
      
    <?php } if($query['status'] == (1 || 4)){ ?>
      
    window.onload = function () {
            CheckTime();
        };
      
    function CheckTime(){
          var price = '<?=$getPack['price'];?>';
          var hsd = document.getElementById("hsd").value;
          
          let tongtien = price * hsd;
          let vndString = tongtien.toLocaleString('vi-VN', { style: 'currency', currency: 'VND' }); 
          let cyberlux = vndString.replace('₫', ''); 
          document.getElementById("price").innerHTML = cyberlux;
      }
      
      function ThanhToan(){
            $("#ThanhToan").html('<i class="fa fa-spinner fa-spin"></i>');
            $.ajax({
                url: "/api/ajaxs/cpanel.php",
                method: "POST",
                data: {
                   id: '<?=$id;?>',
                   hsd: $("#hsd").val(),
                   type: 'giahan'
                },
                success: function(response) {
                 $("#message6").html(response);
                 $("#ThanhToan").html('Thanh Toán - <b id="money"></b> <sup>đ</sup>');
                 CheckTime();
                }
            });
      }
    
      <?php } ?>
      
      function ErrorStatus(){
          swal('Thông Báo','Chức Năng Chỉ Cho Phép Dùng Khi Hosting Hoạt Động','warning');
      }
      
       function SwalChamDut(){
        swal({
          title: "Xác Nhận",
          text: "Bạn Có Chắc Muốn Xóa Dịch Vụ?",
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
        .then((willDelete) => {
          if (willDelete) {
              document.getElementById("submitDelete").submit();
              swal("Tạo Lệnh Chấm Dứt Thành Công, Vui Lòng Đợi", {
              icon: "success",
            });
          }
        });
    }
</script>
                            
                            
                            
                            
                
                
                
<?php
include('../cpn/footer.php');
?>