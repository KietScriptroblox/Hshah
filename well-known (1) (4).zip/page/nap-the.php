<?php
include('../cpn/header.php');
checkSession();
echo Title("Nạp Thẻ Cào");
?>


<div class="main-content app-content">
                    <div class="side-app">
                        <!-- CONTAINER -->
                        <div class="main-container container-fluid px-0">
                                
                            <!-- PAGE-HEADER -->
                            <div class="page-header">
                                <div class="page-leftheader">
                                    <h4 class="page-title mb-0 text-primary"> Nạp Thẻ Cào </h4>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <h3 class="card-title"> Nhập Thông Tin Thẻ </h3>
                                        </div>
                                        <div class="card-body">
                                            <div class="row">
                                                
                                                <div class="form-group col-md-6">
                                                    <label>Mã Thẻ</label>
                                                    <input type="text" class="form-control" placeholder="Mã Thẻ" id="pin">
                                                </div>
                                                
                                                
                                                <div class="form-group col-md-6">
                                                    <label>Serial</label>
                                                    <input type="text" class="form-control" placeholder="Serial" id="serial">
                                                </div>
                                                
                                                
                                               <div class="col-md-6 mb-3">
													<label for="firstName" class="tx-semibold"> Loại Thẻ </label>
													<select class="form-control" id="type">
                                                        <option value="">Chọn loại thẻ</option>
                                                        <option value="VIETTEL">Viettel</option>
                                                        <option value="MOBIFONE">Mobifone</option>
                                                        <option value="VINAPHONE">Vinaphone</option>
                                                        <option value="VIETNAMOBILE">Vietnamobile</option>
                                                        <option value="ZING">Zing</option>
													</select>
												</div>
												
												<div class="col-md-6 mb-3">
													<label for="lastName" class="tx-semibold"> Mệnh Giá </label>
													<select class="form-control" id="amount">
													     <option value="">Chọn mệnh giá</option>
                                                        <option value="10000">10.000đ</option>
                                                        <option value="20000">20.000đ</option>
                                                        <option value="30000">30.000đ</option>
                                                        <option value="50000">50.000đ</option>
                                                        <option value="100000">100.000đ</option>
                                                        <option value="200000">200.000đ</option>
                                                        <option value="300000">300.000đ</option>
                                                        <option value="500000">500.000đ</option>
                                                        <option value="1000000">1.000.000đ</option>
													</select>
												</div>
												
                                            </div>
                                            
                                            <div class="col-md-12">
                                                <button class="btn btn-info" id="NapThe"> Gửi Thẻ </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                
                                <div class="col-md-12 col-lg-12">
								<div class="card custom-card">
									<div class="card-header d-flex">
										<h6 class="main-content-label"> Lịch Sử Nạp Thẻ </h6>
									</div>
									<div class="card-body">
									
									<div class="table-responsive">
												<div id="basic-datatable_wrapper" class="dataTables_wrapper dt-bootstrap5 no-footer">
												<div class="row">
												    <div class="col-sm-12">
												    <table class="table table-bordered text-nowrap border-bottom dataTable no-footer" id="basic-datatable" role="grid" aria-describedby="basic-datatable_info">
												<thead>
													<tr role="row">
													<th class="wd-25p sorting" tabindex="0" aria-controls="basic-datatable" rowspan="1" colspan="1" aria-label="Position: activate to sort column ascending" style="width: 408.889px;"> STT </th>
													<th class="wd-25p sorting" tabindex="0" aria-controls="basic-datatable" rowspan="1" colspan="1" aria-label="Position: activate to sort column ascending" style="width: 408.889px;"> Mã Thẻ </th>
													<th class="wd-20p sorting" tabindex="0" aria-controls="basic-datatable" rowspan="1" colspan="1" aria-label="Office: activate to sort column ascending" style="width: 318.889px;"> Serial </th>
													<th class="wd-15p sorting" tabindex="0" aria-controls="basic-datatable" rowspan="1" colspan="1" aria-label="Age: activate to sort column ascending" style="width: 228.889px;"> Loại Thẻ / Mệnh Giá </th>
													<th class="wd-20p sorting" tabindex="0" aria-controls="basic-datatable" rowspan="1" colspan="1" aria-label="Salary: activate to sort column ascending" style="width: 318.889px;"> Thời Gian Nạp </th>
													<th class="wd-20p sorting" tabindex="0" aria-controls="basic-datatable" rowspan="1" colspan="1" aria-label="Salary: activate to sort column ascending" style="width: 318.889px;"> Trạng Thái </th>
													</tr>
												</thead>
												<tbody>
											
											<?php
											$queryResult = mysqli_query($connect, "SELECT * FROM DataCard WHERE username = '".$getUser['username']."' ORDER BY id DESC");
											while($row = mysqli_fetch_assoc($queryResult)){
											    $id+=1;
											?>
												<tr class="odd">
												    <td><?=Monney($id);?></td>
												        <td> <?=AntiXss($row['pin']);?> </td>
												        <td> <?=AntiXss($row['serial']);?> </td>
												        <td> <?=AntiXss($row['type']);?> / <?=AntiXss(Monney($row['amount']));?> <sup>đ </sup></td>
												        <td><?=ToTime($row['time']);?></td>
														<td><?=StatusCard($row['status']);?></td>
													</tr>
													
													<?php } ?>
													
													</tbody>
											</table>
											</div>
											</div>
											<div class="row">
											    <div class="col-sm-12 col-md-5">
											    <div class="dataTables_info" id="basic-datatable_info" role="status" aria-live="polite">Showing 1 to 10 of 57 entries</div>
											</div>
											</div>
											</div>
										</div>
										
									</div>
								</div>
							</div>
							
                                
                                </div>
                                
                            </div>
                            
                            
                        
                        </div>
                    </div>
                </div>
                 </div>
                 
                 
                         
                <script>
                    $("#NapThe").on("click", function() {
                        $('#NapThe').html('<i class="fa fa-spinner fa-spin"></i> ĐANG XỬ LÝ').prop('disabled',
                            true);
                        $.ajax({
                            url: "/api/ajaxs/napthe.php",
                            method: "POST",
                            data: {
                                pin: $("#pin").val(),
                                serial: $("#serial").val(),
                                type: $("#type").val(),
                                amount: $("#amount").val()
                            },
                            success: function(response) {
                                $("#nhthanhit").html(response);
                                $('#NapThe').html('Gửi Thẻ').prop('disabled', false);
                            }
                        });
                    });
                </script>
                
                <div id="nhthanhit"></div>
                
                
<?php
include('../cpn/footer.php');
?>