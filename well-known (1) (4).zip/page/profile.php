<?php
include('../cpn/header.php');
checkSession();
echo Title("Thông Tin Tài Khoản");
?>


<div class="main-content app-content">
    <div class="side-app">
        <!-- CONTAINER -->
        <div class="main-container container-fluid px-0">
                
            <!-- PAGE-HEADER -->
            <div class="page-header">
                <div class="page-leftheader">
                    <h4 class="page-title mb-0 text-primary">Thông Tin Tài Khoản</h4>
                </div>
            </div>
            
            <div class="tab-pane active" id="editProfile">
											<div class="card">
												<div class="card-body border-0">
													<div class="form-horizontal">
														<div class="row mb-4">
															<p class="mb-4 text-17"> Thông Tin Tài Khoản  </p>
															<div class="col-md-12 col-lg-12 col-xl-6">
																<div class="form-group">
																	<label for="username" class="form-label"> Tên Đăng Nhập </label>
																	<input type="text" class="form-control" value="<?=$getUser['username'];?>" disabled>
																</div>
															</div>
															<div class="col-md-12 col-lg-12 col-xl-6">
																<div class="form-group">
																	<label for="firstname" class="form-label"> Email </label>
																	<input type="text" class="form-control" value="<?=$getUser['email'];?>" disabled>
																</div>
															</div>
															<div class="col-md-12 col-lg-12 col-xl-6">
																<div class="form-group">
																	<label for="lastname" class="form-label"> Số Dư </label>
																	<input type="text" class="form-control" value="<?=Monney($getUser['monney']);?>đ" disabled>
																</div>
															</div>
															
															<div class="col-md-12 col-lg-12 col-xl-6">
																<div class="form-group">
																	<label for="lastname" class="form-label"> Tổng Nạp </label>
																	<input type="text" class="form-control" value="<?=Monney($getUser['total_rechange']);?>đ" disabled>
																</div>
															</div>
															

	                                                    	<div class="col-md-12 col-lg-12 col-xl-6">
																<div class="form-group">
																	<label for="lastname" class="form-label"> Thời Gian Đăng Ký </label>
																	<input type="text" class="form-control" value="<?=ToTime($getUser['time']);?>" disabled>
																</div>
															</div>
															
															
															<div class="col-md-12 col-lg-12 col-xl-6">
																<div class="form-group">
																	<label for="lastname" class="form-label"> Cấp Bậc </label>
																	<input type="text" class="form-control" value="<?=level($getUser['level']);?>" disabled>
																</div>
															</div>
															
														</div>
												
														
													</div>
												</div>
											</div>
										</div>
            
           
    </div>
</div>
 </div>
 

                
<?php
include('../cpn/footer.php');
?>