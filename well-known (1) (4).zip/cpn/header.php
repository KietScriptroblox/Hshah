<?php
include('config.php');
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
	
        <?php
        include('components/head.php');
        ?>

	<body class="app sidebar-mini ltr">


        <?php
        include('components/switcher.php');
        include('components/global-loader.php');
        ?>
        


		<div class="page">
            <div class="page-main">

              <?php
              include('components/app-header.php');
              ?>

                <div class="app-sidebar__overlay" data-bs-toggle="sidebar"></div>
				<div class="sticky">
					<aside class="app-sidebar">
						<div class="app-sidebar__logo">
							<a class="header-brand" href="/">
								<img src="<?=$system32['logo'];?>" class="header-brand-img desktop-lgo"
									alt="Azea logo">
								<img src="<?=$system32['logo'];?>" class="header-brand-img dark-logo"
									alt="Azea logo">
								<img src="<?=$system32['logo'];?>" class="header-brand-img mobile-logo"
									alt="Azea logo">
								<img src="<?=$system32['logo'];?>" class="header-brand-img darkmobile-logo"
									alt="Azea logo">
							</a>
						</div>
						
						<div class="main-sidemenu">
							<div class="slide-left disabled" id="slide-left">
								<svg xmlns="http://www.w3.org/2000/svg" fill="#7b8191" width="24" height="24"
									viewBox="0 0 24 24">
									<path d="M13.293 6.293 7.586 12l5.707 5.707 1.414-1.414L10.414 12l4.293-4.293z" />
								</svg>
							</div>
							<ul class="side-menu app-sidebar3">
								<li class="side-item side-item-category">Main</li>
								<li class="slide">
									<a class="side-menu__item" href="/">
										<svg xmlns="http://www.w3.org/2000/svg" class="side-menu__icon" width="24"
											height="24" viewBox="0 0 24 24">
											<path
												d="M3 13h1v7c0 1.103.897 2 2 2h12c1.103 0 2-.897 2-2v-7h1a1 1 0 0 0 .707-1.707l-9-9a.999.999 0 0 0-1.414 0l-9 9A1 1 0 0 0 3 13zm7 7v-5h4v5h-4zm2-15.586 6 6V15l.001 5H16v-5c0-1.103-.897-2-2-2h-4c-1.103 0-2 .897-2 2v5H6v-9.586l6-6z" />
										</svg>
										<span class="side-menu__label"> Trang Chủ </span></a>
								</li>
								
								
								<li class="side-item side-item-category"> Dịch Vụ </li>
								
								
								<li class="slide">
									<a class="side-menu__item" data-bs-toggle="slide" href="javascript:void(0);">
									    
										<svg xmlns="http://www.w3.org/2000/svg" class="side-menu__icon" width="24"
											height="24" viewBox="0 0 16 16">
											<path d="M6.5 7a.5.5 0 0 0 0 1h4a.5.5 0 0 0 0-1z"/>
                                            <path d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 4 12h1a2 2 0 1 0 0 4 2 2 0 0 0 0-4h7a2 2 0 1 0 0 4 2 2 0 0 0 0-4h1a.5.5 0 0 0 .491-.408l1.5-8A.5.5 0 0 0 14.5 3H2.89l-.405-1.621A.5.5 0 0 0 2 1zm3.915 10L3.102 4h10.796l-1.313 7h-8.17zM6 14a1 1 0 1 1-2 0 1 1 0 0 1 2 0m7 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0"/>
										</svg>
										
										<span class="side-menu__label"> Thiết Kế Web </span><i
											class="angle fe fe-chevron-right"></i></a>
									<ul class="slide-menu">
										<li class="panel sidetab-menu">
											<div class="panel-body tabs-menu-body p-0 border-0">
												<div class="tab-content">
													<div class="tab-pane tab-content-show active" id="side1">
														<ul class="sidemenu-list">
															<li><a href="/thiet-ke-web" class="slide-item"> Thiết Kế Web </a></li>
															<li><a href="/quan-ly-web" class="slide-item"> Lịch Sử Tạo Web </a></li>
														</ul>
													</div>
												</div>
											</div>
										</li>
									</ul>
								</li>
								
								
									<li class="slide">
									<a class="side-menu__item" data-bs-toggle="slide" href="javascript:void(0);">
									    
										<svg xmlns="http://www.w3.org/2000/svg" class="side-menu__icon" width="24"
											height="24" viewBox="0 0 16 16">
											<path d="M6.5 7a.5.5 0 0 0 0 1h4a.5.5 0 0 0 0-1z"/>
                                            <path d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 4 12h1a2 2 0 1 0 0 4 2 2 0 0 0 0-4h7a2 2 0 1 0 0 4 2 2 0 0 0 0-4h1a.5.5 0 0 0 .491-.408l1.5-8A.5.5 0 0 0 14.5 3H2.89l-.405-1.621A.5.5 0 0 0 2 1zm3.915 10L3.102 4h10.796l-1.313 7h-8.17zM6 14a1 1 0 1 1-2 0 1 1 0 0 1 2 0m7 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0"/>
										</svg>
										
										<span class="side-menu__label"> Hosting & Reseller </span><i
											class="angle fe fe-chevron-right"></i></a>
        									<ul class="slide-menu">
        										<li class="panel sidetab-menu">
        											<div class="panel-body tabs-menu-body p-0 border-0">
        												<div class="tab-content">
        													<div class="tab-pane tab-content-show active" id="side1">
        														<ul class="sidemenu-list">
        															<li><a href="/danh-sach-server-hosting" class="slide-item"> Hosting Giá Rẻ </a></li>
        															<li><a href="/danh-sach-server-reseller" class="slide-item"> Reseller Giá Rẻ </a></li>
        															<li><a href="/quan-ly-hosting" class="slide-item"> Lịch Sử Mua Hosting </a></li>
        															<li><a href="/quan-ly-reseller" class="slide-item"> Lịch Sử Mua Reseller </a></li>
        														</ul>
        													</div>
        												</div>
        											</div>
        										</li>
        									</ul>
        								</li>
        								
        								
        									<li class="slide">
									<a class="side-menu__item" data-bs-toggle="slide" href="javascript:void(0);">
									    
										<svg xmlns="http://www.w3.org/2000/svg" class="side-menu__icon" width="24"
											height="24" viewBox="0 0 16 16">
											<path d="M6.5 7a.5.5 0 0 0 0 1h4a.5.5 0 0 0 0-1z"/>
                                            <path d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 4 12h1a2 2 0 1 0 0 4 2 2 0 0 0 0-4h7a2 2 0 1 0 0 4 2 2 0 0 0 0-4h1a.5.5 0 0 0 .491-.408l1.5-8A.5.5 0 0 0 14.5 3H2.89l-.405-1.621A.5.5 0 0 0 2 1zm3.915 10L3.102 4h10.796l-1.313 7h-8.17zM6 14a1 1 0 1 1-2 0 1 1 0 0 1 2 0m7 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0"/>
										</svg>
										
										<span class="side-menu__label"> Tạo Logo & Banner </span><i
											class="angle fe fe-chevron-right"></i></a>
									<ul class="slide-menu">
										<li class="panel sidetab-menu">
											<div class="panel-body tabs-menu-body p-0 border-0">
												<div class="tab-content">
													<div class="tab-pane tab-content-show active" id="side1">
														<ul class="sidemenu-list">
															<li><a href="/thiet-ke-logo-banner" class="slide-item"> Thiết Kế Logo & Banner </a></li>
															<li><a href="/lich-su-thiet-ke" class="slide-item"> Lịch Sử Tạo Thiết Kế </a></li>
														</ul>
													</div>
												</div>
											</div>
										</li>
									</ul>
								</li>
								
        								
        									<li class="slide">
        									<a class="side-menu__item" data-bs-toggle="slide" href="javascript:void(0);">
        									    
        										<svg xmlns="http://www.w3.org/2000/svg" class="side-menu__icon" width="24"
        											height="24" viewBox="0 0 16 16">
        											<path d="M6.5 7a.5.5 0 0 0 0 1h4a.5.5 0 0 0 0-1z"/>
                                                    <path d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 4 12h1a2 2 0 1 0 0 4 2 2 0 0 0 0-4h7a2 2 0 1 0 0 4 2 2 0 0 0 0-4h1a.5.5 0 0 0 .491-.408l1.5-8A.5.5 0 0 0 14.5 3H2.89l-.405-1.621A.5.5 0 0 0 2 1zm3.915 10L3.102 4h10.796l-1.313 7h-8.17zM6 14a1 1 0 1 1-2 0 1 1 0 0 1 2 0m7 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0"/>
        										</svg>
        										
        										<span class="side-menu__label"> Mua Mã Nguồn </span><i
        											class="angle fe fe-chevron-right"></i></a>
        									<ul class="slide-menu">
        										<li class="panel sidetab-menu">
        											<div class="panel-body tabs-menu-body p-0 border-0">
        												<div class="tab-content">
        													<div class="tab-pane tab-content-show active" id="side1">
        														<ul class="sidemenu-list">
        															<li><a href="/mua-source" class="slide-item"> Mua Mã Nguồn </a></li>
        															<li><a href="/lich-su-mua-code" class="slide-item"> Lịch Sử Mua Code </a></li>
        														</ul>
        													</div>
        												</div>
        											</div>
        										</li>
        									</ul>
        								</li>
        								
        								
        									<li class="slide">
									<a class="side-menu__item" data-bs-toggle="slide" href="javascript:void(0);">
									    
										<svg xmlns="http://www.w3.org/2000/svg" class="side-menu__icon" width="24"
											height="24" viewBox="0 0 16 16">
											<path d="M6.5 7a.5.5 0 0 0 0 1h4a.5.5 0 0 0 0-1z"/>
                                            <path d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 4 12h1a2 2 0 1 0 0 4 2 2 0 0 0 0-4h7a2 2 0 1 0 0 4 2 2 0 0 0 0-4h1a.5.5 0 0 0 .491-.408l1.5-8A.5.5 0 0 0 14.5 3H2.89l-.405-1.621A.5.5 0 0 0 2 1zm3.915 10L3.102 4h10.796l-1.313 7h-8.17zM6 14a1 1 0 1 1-2 0 1 1 0 0 1 2 0m7 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0"/>
										</svg>
										
										<span class="side-menu__label"> Mua Tên Miền </span><i
											class="angle fe fe-chevron-right"></i></a>
									<ul class="slide-menu">
										<li class="panel sidetab-menu">
											<div class="panel-body tabs-menu-body p-0 border-0">
												<div class="tab-content">
													<div class="tab-pane tab-content-show active" id="side1">
														<ul class="sidemenu-list">
															<li><a href="/bang-gia-mien" class="slide-item"> Bảng Giá Miền </a></li>
															<li><a href="/lich-su-mua-mien" class="slide-item"> Lịch Sử Mua Miền </a></li>
														</ul>
													</div>
												</div>
											</div>
										</li>
									</ul>
								</li>
								
        								
							
								<li class="side-item side-item-category"> Nạp Tiền & Giảm Giá </li>
								
        								
        								<li class="slide">
        									<a class="side-menu__item" href="/gift-code">
        									    
        									<svg xmlns="http://www.w3.org/2000/svg" class="side-menu__icon" width="24"
											height="24" viewBox="0 0 16 16">
											<path d="M3 2.5a2.5 2.5 0 0 1 5 0 2.5 2.5 0 0 1 5 0v.006c0 .07 0 .27-.038.494H15a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1v7.5a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 1 14.5V7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h2.038A2.968 2.968 0 0 1 3 2.506zm1.068.5H7v-.5a1.5 1.5 0 1 0-3 0c0 .085.002.274.045.43a.522.522 0 0 0 .023.07M9 3h2.932a.56.56 0 0 0 .023-.07c.043-.156.045-.345.045-.43a1.5 1.5 0 0 0-3 0zM1 4v2h6V4zm8 0v2h6V4zm5 3H9v8h4.5a.5.5 0 0 0 .5-.5zm-7 8V7H2v7.5a.5.5 0 0 0 .5.5z"/>
										</svg>
        										<span class="side-menu__label"> Mã Giảm Giá </span>
        										<i
        											class="angle fe fe-chevron-right"></i></a>

        								</li> 
        								
        								
        								
        								<li class="slide">
        									<a class="side-menu__item" data-bs-toggle="slide" href="javascript:void(0);">
        									    
        										<svg xmlns="http://www.w3.org/2000/svg" class="side-menu__icon" width="24"
        											height="24" viewBox="0 0 16 16">
        											<path d="M14 3a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1zM2 2a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2z"/>
                                                     <path d="M2 5.5a.5.5 0 0 1 .5-.5h2a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5zm0 3a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5m0 2a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5m3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5m3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5m3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5"/>
        										</svg>
        										
        										<span class="side-menu__label"> Nạp Tiền </span><i
        											class="angle fe fe-chevron-right"></i></a>
            									<ul class="slide-menu">
            										<li class="panel sidetab-menu">
            											<div class="panel-body tabs-menu-body p-0 border-0">
            												<div class="tab-content">
            													<div class="tab-pane tab-content-show active" id="side1">
            														<ul class="sidemenu-list">
            															<li><a href="/nap-the" class="slide-item"> Nạp Thẻ </a></li>
            															<li><a href="/nap-tien" class="slide-item"> Nạp Ngân Hàng & Ví </a></li>
            														</ul>
            													</div>
            												</div>
            											</div>
            										</li>
            									</ul>
            								</li>
        								
        							
        								
      
            							</ul>
            							<div class="slide-right" id="slide-right">
            								<svg xmlns="http://www.w3.org/2000/svg" fill="#7b8191" width="24" height="24"
            									viewBox="0 0 24 24">
            									<path d="M10.707 17.707 16.414 12l-5.707-5.707-1.414 1.414L13.586 12l-4.293 4.293z" />
            								</svg>
            							</div>
            						</div>
            					</aside>
            				</div>

              