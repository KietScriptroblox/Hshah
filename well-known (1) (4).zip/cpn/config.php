<?php
session_start();

$localhost = 'localhost';
$database = 'tsntgamevnlink_vn';
$userbase = 'tsntgamevnlink_vn';
$passbase = 'tsntgamevnlink_vn';

$connect = mysqli_connect($localhost, $database, $userbase, $passbase) or die("Không thể kết nối đến cơ sở dữ liệu!");
$connect->query("SET NAMES 'UTF8'");
date_default_timezone_set('Asia/Ho_Chi_Minh'); 

if(isset($_SESSION['users'])){
    $getUser = $connect->query("SELECT * FROM Users WHERE username = '".$_SESSION['users']."'")->fetch_array();
    if($_SESSION['users'] != $getUser['username']){
        unset($_SESSION['users']);
    }
    
    $connect->query("UPDATE `Users` SET `date_online`='".time()."'WHERE username = '".$getUser['username']."'");
}

$hostapi = '';

function distanceTime($thoiDiem){
    $thoiGianHienTai = time();
    $khoangCach = $thoiGianHienTai - $thoiDiem;

    if ($khoangCach < 60) {
        return $khoangCach . " giây trước";
    } elseif ($khoangCach < 3600) {
        return round($khoangCach / 60) . " phút trước";
    } elseif ($khoangCach < 86400) {
        return round($khoangCach / 3600) . " giờ trước";
    } else {
        return round($khoangCach / 86400) . " ngày trước";
    }
}

function json_api($text, $status){
    echo json_encode(['message' => $text, 'status' => $status]);
}

function sendEmail($receiverEmail, $receiverName, $subject, $content, $bccEmail){
    global $smtpUsername, $smtpPassword;
    
    include $_SERVER['DOCUMENT_ROOT'].'/smtp/class.smtp.php';
    include $_SERVER['DOCUMENT_ROOT'].'/smtp/PHPMailerAutoload.php';
    include $_SERVER['DOCUMENT_ROOT'].'/smtp/class.phpmailer.php';

    // Sử dụng thư viện PHPMailer
    $mail = new PHPMailer();
    $mail->SMTPDebug = 0; // Bật chế độ debug ở mức 0 để tắt debug hoàn toàn
    $mail->Debugoutput = "html"; // Ghi lại thông tin debug dưới dạng HTML
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = $smtpUsername; // Địa chỉ email Gmail gửi
    $mail->Password = $smtpPassword; // Mật khẩu email Gmail gửi
    $mail->SMTPSecure = 'tls';
    $mail->protocol = 'mail';
    $mail->Port = 587;
    $mail->setFrom($smtpUsername, $bccEmail);
    $mail->addAddress($receiverEmail, $receiverName);
    $mail->addReplyTo($smtpUsername, $bccEmail);
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body = $content;
    $mail->CharSet = 'UTF-8';
    $send = $mail->send();
    return $send;
}

function calculatePercentage($amount, $percentage) {
    return ($amount * $percentage) / 100;
}

function tinhNgay($time, $timedn){
    $ngayMua = new DateTime("@" . $time);
    $ngayHetHan = new DateTime("@" . $timedn);
    $soNgay = $ngayHetHan->diff($ngayMua)->days;
    
    return $soNgay;
}

function level($level){
    if($level == null){
        return "Thành Viên";
    } else if($level == 'admin'){
        return "Quản Trị Viên";
    }
}

function TruTienDichVu($time, $amount, $hsd){
$ngayMua = $time; 
$ngayHienTai = time(); 
$soNgay = floor(($ngayHienTai - $ngayMua) / (60 * 60 * 24));

$giaDichVu = $amount; 
$tienConDu = max(0, $giaDichVu - ($soNgay * ($giaDichVu / $hsd)));
return $tienConDu;
}

function checkGia($price, $giam) {
    $result = $price - ($price * ($giam / 100));
    return $result;
}

function ToTime($time){
    return date('d/m/Y - h:i:s', $time);
}

function inHoaString($text){
    return strtoupper($text);
}

function inOneString($text){
    return ucwords($text);
}

function inThuongString($text){
    return strtolower($text);
}

function redirect($url){
    return('<meta http-equiv="refresh" content="0;url='.$url.'">');
}

function ReturnXss($text){
    return htmlspecialchars_decode($text, ENT_QUOTES);
}

function AntiXss($text){
    return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
}

function Monney($monney){
    return str_replace(".", ",", number_format($monney));
}

function swal($text, $status){
    return '<script>swal("Thông Báo", "'.$text.'", "'.$status.'");</script>';
}

function isDomainRegistered($domain) {
    if (file_get_contents("http://www.whois.net.vn/whois.php?domain=".$domain) == 0) {
        return true;
    } else {
        return false;
    }
}

function resultDomain($domain, $price, $status){
    if($status == 'true'){
  return '<tr>
            <td class="fs-base"> 
              <span class="badge rounded-pill bg-success"> Có Thể Đăng Ký
              </span>
            </td>
            
            <td class="text-center">
              <a class="fw-semibold">
                '.$domain.'
              </a>
            </td>
            
            <td class="text-center">
              <strong> '.Monney($price).' <sup>đ</sup></strong>
            </td>
            
            <td class="text-center fs-base">
              <a class="btn btn-sm btn-alt-secondary" onclick="toUrl(`'.$domain.'`);">
                <i class="fa fa-fw fa-cart-plus"></i>
              </a>
            </td>
          </tr>
          '; 
          
} else if($status == 'false'){
       return '<tr>
            <td class="fs-base">
              <span class="badge rounded-pill bg-danger"> Đã được đăng ký</span>
            </td>
            
            <td class="text-center">
              <a class="fw-semibold">
                '.$domain.'
              </a>
            </td>
            
            <td class="text-center">
              <strong> '.Monney($price).' <sup>đ</sup></strong>
            </td>
            
            <td class="text-center fs-base">
              <a class="btn btn-sm btn-alt-secondary">
                <i class="fa fa-fw fa-circle-xmark"></i>
              </a>
            </td>
          </tr>
          '; 
          
} else if($status == 'null'){
  return '<tr>
            <td class="fs-base">
              <span class="badge rounded-pill bg-warning"> Không khả dụng </span>
            </td>
            
            <td class="text-center">
              <a class="fw-semibold">
                '.$domain.'
              </a>
            </td>
            
            <td class="text-center">
              <strong> '.Monney($price).' <sup>đ</sup></strong>
            </td>
            
            <td class="text-center fs-base">
              <a class="btn btn-sm btn-alt-secondary">
                <i class="fa fa-window-close"></i>
              </a>
            </td>
          </tr>
          '; 
}

}

function StatusAdminHost($status){
    if($status == 'on'){
        echo '<span class="badge bg-info"> Hiển Thị </span>';
    } else {
         echo '<span class="badge bg-danger"> Ẩn </span>';
    }
}


function Title($text){
    return '<script>document.title = "'.$text.'";</script>';
}

function checkSession(){
    if(!isset($_SESSION['users'])){
        echo redirect('/login');
        exit;
    }
}


function StatusLogo($status, $id){
    if($status == '0'){
        return '<button class="btn btn-primary"> Đang Xử Lí </button>';
    } else if($status == '1'){
        return '<button class="btn btn-success"> Hoàn Thành </button>';
    } else if($status == '2'){
        return '<button class="btn btn-danger"> Bị Hủy </button>';
    } else {
        return '<button class="btn btn-danger"> Không Xác Định </button>';
    }
}


function StatusShop($status){
    if($status == '0'){
        return '<button class="btn btn-primary"> Đang Xử Lý </button>';
    } else if($status == '1'){
        return '<button class="btn btn-success"> Hoạt Động </button>';
    } else if($status == '2'){
        return '<button class="btn btn-danger"> Hết Hạn </button>';
    } else if($status == '3'){
        return '<button class="btn btn-warning"> Tạm Khóa </button>';
    } else if($status == '4'){
        return '<button class="btn btn-warning"> Chờ Gia Hạn </button>';
    } else if($status == '5'){
        return '<button class="btn btn-danger"> Bị Khóa </button>';
    } else if($status == '6'){
        return '<button class="btn btn-danger"> Không Khả Dụng </button>';
    } else {
        return '<button class="btn btn-danger"> Không Xác Định </button>';
    }
}

function StatusHost($status){
    if($status == '0'){
        return '<button class="btn btn-primary"> Đang Xử Lý </button>';
    } else if($status == '1'){
        return '<button class="btn btn-success"> Hoạt Động </button>';
    } else if($status == '2'){
        return '<button class="btn btn-danger"> Hết Hạn </button>';
    } else if($status == '3'){
        return '<button class="btn btn-warning"> Tạm Khóa </button>';
    } else if($status == '4'){
        return '<button class="btn btn-warning"> Chờ Gia Hạn </button>';
    } else if($status == '5'){
        return '<button class="btn btn-danger"> Bị Khóa </button>';
    } else if($status == '6'){
        return '<button class="btn btn-danger"> Không Khả Dụng </button>';
    } else {
        return '<button class="btn btn-danger"> Không Xác Định </button>';
    }
}


function StatusMomo($status){
    if($status == '0'){
        return '<button class="btn btn-primary"> Đang Xử Lý </button>';
    } else if($status == '1'){
        return '<button class="btn btn-success"> Hoàn Thành </button>';
    } 
}

function StatusCard($status){
     if($status == '0'){
        return '<button class="btn btn-primary"> Đang Kiểm Tra </button>';
    } else if($status == '1'){
        return '<button class="btn btn-success"> Thẻ Đúng </button>';
    } else if($status == '2'){
        return '<button class="btn btn-danger"> Thẻ Sai </button>';
    } else {
        return '<button class="btn btn-danger"> Không Xác Định </button>';
    }
}


function StatusDomain($status){
    if($status == '0'){
        return '<button class="btn btn-primary"> Đang Xử Lý </button>';
    } else if($status == '1'){
        return '<button class="btn btn-success"> Hoạt Động </button>';
    } else if($status == '2'){
        return '<button class="btn btn-danger"> Hết Hạn </button>';
    } else if($status == '3'){
        return '<button class="btn btn-danger"> Bị Hủy </button>';
    } else if($status == '4'){
        return '<button class="btn btn-danger"> Bị Hủy & Hoàn Tiền </button>';
    } else {
        return '<button class="btn btn-danger"> Không Xác Định </button>';
    }
}

function HienThi($status){
     if($status == 'on'){
         return '<span class="badge badge-primary"> Hiển Thị </span>';
     } else {
         return '<span class="badge badge-danger"> Ẩn </span>';
     }  
}

function RandStrings($length) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $string = '';
    for ($i = 0; $i < $length; $i++) {
        $string .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $string;
}

$system32 = $connect->query("SELECT * FROM System32 WHERE id = '1'")->fetch_array();
$apikey = $system32['token']; # APIKEY TẠI CYBERLUX.VN
?>
