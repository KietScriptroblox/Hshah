</div>           <!-- MAIN-FOOTER -->
            <footer class="footer">
                <div class="container">
                    <div class="row align-items-center flex-row-reverse">
                        <div class="col-md-12 col-sm-12 text-center">
                            <b> Copyright © <?=date('Y');?> <a href="/"> <?=inHoaString($_SERVER['HTTP_HOST']);?> </a>. PHÁT TRIỂN BỞI <strong class="text-danger"> SNTGAMECN.SITE </strong></b>
                        </div>
                    </div>
                </div>
            </footer>
          
		</div>
    
        <a href="#top" id="back-to-top"><i class="fe fe-chevron-up"></i></a>

        <script src="/build/assets/plugins/jquery/jquery.min.js"></script>
        <script src="/build/assets/plugins/bootstrap/popper.min.js"></script>
        <script src="/build/assets/plugins/bootstrap/js/bootstrap.min.js"></script>

        <script src="/build/assets/plugins/p-scrollbar/p-scrollbar.js"></script>
        <script src="/build/assets/plugins/p-scrollbar/p-scroll1.js"></script>
        <script src="/build/assets/plugins/p-scrollbar/p-scroll.js"></script>

        <script src="/build/assets/plugins/sidemenu/sidemenu.js"></script>

        <script src="/build/assets/plugins/flot/jquery.flot.js"></script>
        <script src="/build/assets/plugins/flot/jquery.flot.fillbetween.js"></script>
        <script src="/build/assets/plugins/flot/jquery.flot.pie.js"></script>
        <script src="/build/assets/dashboard.sampledata.js"></script>
        <script src="/build/assets/chart.flot.sampledata.js"></script>

        <script src="/build/assets/plugins/chart/chart.bundle.js"></script>
        <script src="/build/assets/plugins/chart/utils.js"></script>

        <link rel="modulepreload" href="/build/assets/apexcharts.aa300a8e.js" /><script type="module" src="/build/assets/apexcharts.aa300a8e.js"></script>

        <script src="/build/assets/plugins/moment/moment.js"></script>

        <script src="/build/assets/plugins/datatables/DataTables/js/jquery.dataTables.js"></script>
        <script src="/build/assets/plugins/datatables/DataTables/js/dataTables.bootstrap5.js"></script>
        <script src="/build/assets/plugins/datatables/Responsive/js/dataTables.responsive.min.js"></script>
        <script src="/build/assets/plugins/datatables/Responsive/js/responsive.bootstrap5.min.js"></script>

        <script src="/build/assets/plugins/select2/select2.full.min.js"></script>
        <link rel="modulepreload" href="/build/assets/select2.f64e42a1.js" /><script type="module" src="/build/assets/select2.f64e42a1.js"></script>

        <script src="/build/assets/plugins/simplebar/js/simplebar.min.js"></script>
        
        <link rel="modulepreload" href="/build/assets/index1.868fabe2.js" /><link rel="modulepreload" href="/build/assets/apexcharts.common.4772fa83.js" /><script type="module" src="/build/assets/index1.868fabe2.js"></script>


		<script src="/build/assets/sticky.js"></script>

        <link rel="modulepreload" href="/build/assets/themeColors.2c059b7b.js" /><link rel="modulepreload" href="/build/assets/index.f251b3e5.js" /><link rel="modulepreload" href="/build/assets/apexcharts.common.4772fa83.js" /><script type="module" src="/build/assets/themeColors.2c059b7b.js"></script>

		<link rel="modulepreload" href="/build/assets/app.f4590aff.js" /><link rel="modulepreload" href="/build/assets/index.f251b3e5.js" /><link rel="modulepreload" href="/build/assets/apexcharts.common.4772fa83.js" /><script type="module" src="/build/assets/app.f4590aff.js"></script>

        <link rel="modulepreload" href="/build/assets/switcher.c110dd63.js" /><script type="module" src="/build/assets/switcher.c110dd63.js"></script>

	</body>

</html><audio src="https://hocban.vn/wp-content/uploads/2017/07/y2meta.com - Có Duyên Không Nợ Remix - Tina Ho Cover x TVT _ Một Người Đứng Từ Xa Chờ Anh Về Remix Tiktok (128 kbps).mp3