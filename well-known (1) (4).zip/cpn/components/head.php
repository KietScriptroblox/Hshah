<head>

        <meta charset="UTF-8">
        <meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
        <meta name="Description" content="<?=$system32['description'];?>">
        <meta name="Author" content="<?=$system32['author'];?>">
        <meta name="keywords" content="<?=$system32['keywords'];?>">

		<title> <?=$system32['title'];?> </title>
		<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script><script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
		<link rel="icon" href="/build/assets/images/brand/favicon.png" type="image/x-icon">
	    <link id="style" href="/build/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link rel="preload" as="style" href="/build/assets/app.57719e07.css" /><link rel="stylesheet" href="/build/assets/app.57719e07.css" />
        <link href="/build/assets/iconfonts/icons.css" rel="stylesheet">
        <link href="/build/assets/iconfonts/animated.css" rel="stylesheet">
        <link rel="preload" as="style" href="/build/assets/app.f0e6a016.css" /><link rel="stylesheet" href="/build/assets/app.f0e6a016.css" />
	</head>