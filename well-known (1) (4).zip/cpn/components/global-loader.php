	<div id="global-loader" >
			<img src="/build/assets/images/svgs/loader.svg" class="loader-img" alt="loader">
		</div>